<table>
<colgroup>
<col style="width: 37%" />
<col style="width: 62%" />
</colgroup>
<tbody>
<tr class="odd">
<td><strong>THỦ TƯỚNG CHÍNH PHỦ<br />
-------</strong></td>
<td><strong>CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM<br />
Độc lập - Tự do - Hạnh phúc<br />
---------------</strong></td>
</tr>
<tr class="even">
<td>Số: 19/2025/QĐ-TTg</td>
<td><em>Hà Nội, ngày 30 tháng 6 năm 2025</em></td>
</tr>
</tbody>
</table>

 

**QUYẾT ĐỊNH**

BAN HÀNH BẢNG DANH MỤC VÀ MÃ SỐ CÁC ĐƠN VỊ HÀNH CHÍNH VIỆT NAM

*Căn cứ* *Luật Tổ chức Chính phủ ngày 18 tháng 02 năm 2025;*

*Căn cứ* *Luật Thống kê ngày 23 tháng 11 năm 2015;* *Luật sửa đổi, bổ sung một số điều và Phụ lục Danh mục chi tiêu thống kê quốc gia của Luật Thống kê ngày 12 tháng 11 năm 2021;*

*Theo đề nghị của Bộ trưởng Bộ Tài chính;*

*Thủ tướng Chính phủ ban hành Bảng danh mục và mã số các đơn vị hành chính Việt Nam.*

**Điều 1. Phạm vi điều chỉnh và đối tượng áp dụng**

1\. Quyết định này quy định Bảng danh mục và mã số các đơn vị hành chính Việt Nam; nguyên tắc xác định, quản lý, sử dụng bảng danh mục và mã số các đơn vị hành chính Việt Nam.

2\. Quyết định này áp dụng đối với các bộ, ngành, cơ quan, tổ chức, cá nhân sử dụng Bảng danh mục và mã số các đơn vị hành chính Việt Nam.

**Điều 2. Bảng danh mục và mã số các đơn vị hành chính Việt Nam**

1\. Bảng danh mục và mã số các đơn vị hành chính Việt Nam từ ngày 01 tháng 7 năm 2025 được ban hành kèm theo Quyết định này để sử dụng thống nhất trong cả nước, gồm:

a\) Danh mục và mã số các đơn vị hành chính cấp tỉnh (Phụ lục I kèm theo).

b\) Danh mục và mã số các đơn vị hành chính cấp xã (Phụ lục II kèm theo).

2\. Mã số cấp cho một đơn vị hành chính là số định danh duy nhất, không thay đổi trong suốt quá trình đơn vị hành chính đó tồn tại thực tế. Mã số đã cấp không được sử dụng để cấp lại cho đơn vị hành chính khác cùng cấp.

3\. Cấu trúc mã số đơn vị hành chính

Mã số đơn vị hành chính được phân làm 2 cấp độc lập, mỗi cấp có mã số mở để cấp mã số mới cho đơn vị hành chính khi thay đổi. Cụ thể:

a\) Mã số của đơn vị hành chính cấp tỉnh được xác định bằng 02 chữ số từ số 01 đến 99;

b\) Mã số của đơn vị hành chính cấp xã được xác định bằng 05 chữ số từ số 00001 đến 99999.

**Điều 3. Nguyên tắc xác định mã số đơn vị hành chính khi có thay đổi**

1\. Đối với cấp tỉnh

a\) Trường hợp tách tỉnh

Tỉnh có trụ sở Ủy ban nhân dân đóng trên địa điểm cũ thì mã số đơn vị hành chính cấp tỉnh và cấp xã không thay đổi.

Tỉnh có trụ sở Ủy ban nhân dân đóng trên địa điểm mới được cấp mã tỉnh mới, mã số đơn vị hành chính cấp xã thuộc tỉnh đó không thay đổi.

b\) Trường hợp nhập tỉnh

Tỉnh hợp nhất có trụ sở Ủy ban nhân dân đóng tại tỉnh nào thì mang mã số của tỉnh đó, mã số của tỉnh còn lại sẽ bị đóng và không cấp lại cho đơn vị hành chính khác. Mã số cấp xã của tỉnh hợp nhất không thay đổi.

2\. Đối với cấp xã

a\) Trường hợp tách xã

Xã có trụ sở Ủy ban nhân dân đóng trên địa điểm cũ thì mang mã số cũ.

Xã có trụ sở Ủy ban nhân dân đóng trên địa điểm mới được cấp mã số mới.

b\) Trường hợp nhập xã

Xã hợp nhất có trụ sở Ủy ban nhân dân đóng tại xã nào thì mang mã số của xã đó, mã số của xã còn lại bị đóng và không cấp lại cho đơn vị hành chính khác.

3\. Trường hợp đơn vị hành chính các cấp đổi tên, điều chỉnh từ khu vực nông thôn sang thành thị hoặc ngược lại thì mã số không thay đổi.

**Điều 4. Quản lý, sử dụng bảng danh mục và mã số đơn vị hành chính**

1\. Thủ tướng Chính phủ ban hành bảng Danh mục và mã số các đơn vị hành chính Việt Nam. Bộ Tài chính (Cục Thống kê) có trách nhiệm quản lý hệ thống mã số đơn vị hành chính các cấp trong cả nước.

2\. Căn cứ vào Nghị quyết của Quốc hội, Nghị quyết của Ủy ban Thường vụ Quốc hội về việc thay đổi đơn vị hành chính, Bộ Tài chính (Cục Thống kê) có trách nhiệm sắp xếp, đóng mã số, cấp mã số đơn vị hành chính các cấp và thông báo kịp thời cho các đơn vị trong toàn quốc để thống nhất sử dụng.

**Điều 5. Hiệu lực thi hành**

1\. Quyết định này có hiệu lực thi hành từ ngày 01 tháng 7 năm 2025.

2\. Quyết định số 124/2004/QĐ-TTg ngày 08 tháng 7 năm 2004 của Thủ tướng Chính phủ ban hành Bảng Danh mục và mã số các đơn vị hành chính Việt Nam hết hiệu lực kể từ ngày Quyết định này có hiệu lực.

**Điều 6. Trách nhiệm thi hành**

1\. Bộ Tài chính (Cục Thống kê)

Quản lý, sắp xếp và cấp mã số mới cho đơn vị hành chính các cấp khi có thay đổi.

Hướng dẫn các bộ, ngành, cơ quan thực hiện theo đúng quy định của Quyết định này.

2\. Bộ trưởng, Thủ trưởng cơ quan ngang bộ, Thủ trưởng cơ quan thuộc Chính phủ, Chủ tịch Ủy ban nhân dân tỉnh, thành phố trực thuộc trung ương và Thủ trưởng các cơ quan có liên quan chịu trách nhiệm thi hành Quyết định này.

 

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p> </p>
<p><em><strong>Nơi nhận:<br />
</strong>-</em> Ban Bí thư Trung ương Đảng;<br />
- Thủ tướng, các Phó Thủ tướng Chính phủ;<br />
- Các bộ, cơ quan ngang bộ, cơ quan thuộc Chính phủ;<br />
- HĐND, UBND các tỉnh, thành phố trực thuộc trung ương;<br />
- Văn phòng Trung ương và các Ban của Đảng;<br />
- Văn phòng Tổng Bí thư;<br />
- Văn phòng Chủ tịch nước;<br />
- Hội đồng Dân tộc và các Ủy ban của Quốc hội;<br />
- Văn phòng Quốc hội;<br />
- Toà án nhân dân tối cao;<br />
- Viện kiểm sát nhân dân tối cao;<br />
- Kiểm toán nhà nước;<br />
- Ủy ban Trung ương Mặt trận Tổ quốc Việt Nam;<br />
- Cơ quan trung ương của các đoàn thể;<br />
- VPCP: BTCN, các PCN, Trợ lý TTg, TGĐ cổng TTĐT, các Vụ, Cục, đơn vị trực thuộc, Công báo;<br />
- Lưu: VT, TCCV (2b).</p></td>
<td><strong>KT. THỦ TƯỚNG<br />
PHÓ THỦ TƯỚNG<br />
<br />
<br />
<br />
<br />
Nguyễn Hòa Bình</strong></td>
</tr>
</tbody>
</table>

 

**PHỤ LỤC I**

DANH MỤC VÀ MÃ SỐ CÁC ĐƠN VỊ HÀNH CHÍNH CẤP TỈNH  
*(Kèm theo Quyết định số 19/2025/QĐ-TTg ngày 30 tháng 6 năm 2025 của Thủ tướng Chính phủ)*

|         |           |                         |
|---------|-----------|-------------------------|
| **STT** | **Mã số** | **Tên tỉnh, thành phố** |
| 1       | 01        | Thành phố Hà Nội        |
| 2       | 04        | Tỉnh Cao Bằng           |
| 3       | 08        | Tỉnh Tuyên Quang        |
| 4       | 11        | Tỉnh Điện Biên          |
| 5       | 12        | Tỉnh Lai Châu           |
| 6       | 14        | Tỉnh Sơn La             |
| 7       | 15        | Tỉnh Lào Cai            |
| 8       | 19        | Tỉnh Thái Nguyên        |
| 9       | 20        | Tỉnh Lạng Sơn           |
| 10      | 22        | Tỉnh Quảng Ninh         |
| 11      | 24        | Tỉnh Bắc Ninh           |
| 12      | 25        | Tỉnh Phú Thọ            |
| 13      | 31        | Thành phố Hải Phòng     |
| 14      | 33        | Tỉnh Hưng Yên           |
| 15      | 37        | Tỉnh Ninh Bình          |
| 16      | 38        | Tỉnh Thanh Hóa          |
| 17      | 40        | Tỉnh Nghệ An            |
| 18      | 42        | Tỉnh Hà Tĩnh            |
| 19      | 44        | Tỉnh Quảng Trị          |
| 20      | 46        | Thành phố Huế           |
| 21      | 48        | Thành phố Đà Nẵng       |
| 22      | 51        | Tỉnh Quảng Ngãi         |
| 23      | 52        | Tỉnh Gia Lai            |
| 24      | 56        | Tỉnh Khánh Hòa          |
| 25      | 66        | Tỉnh Đắk Lắk            |
| 26      | 68        | Tỉnh Lâm Đồng           |
| 27      | 75        | Tỉnh Đồng Nai           |
| 28      | 79        | Thành phố Hồ Chí Minh   |
| 29      | 80        | Tỉnh Tây Ninh           |
| 30      | 82        | Tỉnh Đồng Tháp          |
| 31      | 86        | Tỉnh Vĩnh Long          |
| 32      | 91        | Tỉnh An Giang           |
| 33      | 92        | Thành phố Cần Thơ       |
| 34      | 96        | Tỉnh Cà Mau             |

 

**PHỤ LỤC II**

DANH MỤC VÀ MÃ SỐ CÁC ĐƠN VỊ HÀNH CHÍNH CẤP XÃ  
*(Kèm theo Quyết định số 19/2025/QĐ-TTg ngày 30 tháng 6 năm 2025 của Thủ tướng Chính phủ)*

**01. THÀNH PHỐ HÀ NỘI**

**(Tổng số đơn vị hành chính cấp xã: 126, gồm 75 xã, 51 phường)**

|           |                                |
|-----------|--------------------------------|
| **Mã số** | **Tên đơn vị hành chính**      |
| 00004     | Phường Ba Đình                 |
| 00008     | Phường Ngọc Hà                 |
| 00025     | Phường Giảng Võ                |
| 00070     | Phường Hoàn Kiếm               |
| 00082     | Phường Cửa Nam                 |
| 00091     | Phường Phú Thượng              |
| 00097     | Phường Hồng Hà                 |
| 00103     | Phường Tây Hồ                  |
| 00118     | Phường Bồ Đề                   |
| 00127     | Phường Việt Hưng               |
| 00136     | Phường Phúc Lợi                |
| 00145     | Phường Long Biên               |
| 00160     | Phường Nghĩa Đô                |
| 00166     | Phường Cầu Giấy                |
| 00175     | Phường Yên Hòa                 |
| 00190     | Phường Ô Chợ Dừa               |
| 00199     | Phường Láng                    |
| 00226     | Phường Văn Miếu - Quốc Tử Giám |
| 00229     | Phường Kim Liên                |
| 00235     | Phường Đống Đa                 |
| 00256     | Phường Hai Bà Trưng            |
| 00283     | Phường Vĩnh Tuy                |
| 00292     | Phường Bạch Mai                |
| 00301     | Phường Vĩnh Hưng               |
| 00316     | Phường Định Công               |
| 00322     | Phường Tương Mai               |
| 00328     | Phường Lĩnh Nam                |
| 00331     | Phường Hoàng Mai               |
| 00337     | Phường Hoàng Liệt              |
| 00340     | Phường Yên Sở                  |
| 00352     | Phường Phương Liệt             |
| 00364     | Phường Khương Đình             |
| 00367     | Phường Thanh Xuân              |
| 00592     | Phường Từ Liêm                 |
| 00598     | Phường Thượng Cát              |
| 00602     | Phường Đông Ngạc               |
| 00611     | Phường Xuân Đỉnh               |
| 00613     | Phường Tây Tựu                 |
| 00619     | Phường Phú Diễn                |
| 00622     | Phường Xuân Phương             |
| 00634     | Phường Tây Mỗ                  |
| 00637     | Phường Đại Mỗ                  |
| 00643     | Phường Thanh Liệt              |
| 09552     | Phường Kiến Hưng               |
| 09556     | Phường Hà Đông                 |
| 09562     | Phường Yên Nghĩa               |
| 09568     | Phường Phú Lương               |
| 09574     | Phường Sơn Tây                 |
| 09604     | Phường Tùng Thiện              |
| 09886     | Phường Dương Nội               |
| 10015     | Phường Chương Mỹ               |
| 00376     | Xã Sóc Sơn                     |
| 00382     | Xã Kim Anh                     |
| 00385     | Xã Trung Giã                   |
| 00430     | Xã Đa Phúc                     |
| 00433     | Xã Nội Bài                     |
| 00454     | Xã Đông Anh                    |
| 00466     | Xã Phúc Thịnh                  |
| 00475     | Xã Thư Lâm                     |
| 00493     | Xã Thiên Lộc                   |
| 00508     | Xã Vĩnh Thanh                  |
| 00541     | Xã Phù Đổng                    |
| 00562     | Xã Thuận An                    |
| 00565     | Xã Gia Lâm                     |
| 00577     | Xã Bát Tràng                   |
| 00640     | Xã Thanh Trì                   |
| 00664     | Xã Đại Thanh                   |
| 00679     | Xã Ngọc Hồi                    |
| 00685     | Xã Nam Phù                     |
| 04930     | Xã Yên Xuân                    |
| 08974     | Xã Quang Minh                  |
| 08980     | Xã Yên Lãng                    |
| 08995     | Xã Tiến Thắng                  |
| 09022     | Xã Mê Linh                     |
| 09616     | Xã Đoài Phương                 |
| 09619     | Xã Quảng Oai                   |
| 09634     | Xã Cổ Đô                       |
| 09661     | Xã Minh Châu                   |
| 09664     | Xã Vật Lại                     |
| 09676     | Xã Bất Bạt                     |
| 09694     | Xã Suối Hai                    |
| 09700     | Xã Ba Vì                       |
| 09706     | Xã Yên Bài                     |
| 09715     | Xã Phúc Thọ                    |
| 09739     | Xã Phúc Lộc                    |
| 09772     | Xã Hát Môn                     |
| 09784     | Xã Đan Phượng                  |
| 09787     | Xã Liên Minh                   |
| 09817     | Xã Ô Diên                      |
| 09832     | Xã Hoài Đức                    |
| 09856     | Xã Dương Hòa                   |
| 09871     | Xã Sơn Đồng                    |
| 09877     | Xã An Khánh                    |
| 09895     | Xã Quốc Oai                    |
| 09910     | Xã Kiều Phú                    |
| 09931     | Xã Hưng Đạo                    |
| 09952     | Xã Phú Cát                     |
| 09955     | Xã Thạch Thất                  |
| 09982     | Xã Hạ Bằng                     |
| 09988     | Xã Hòa Lạc                     |
| 10003     | Xã Tây Phương                  |
| 10030     | Xã Phú Nghĩa                   |
| 10045     | Xã Xuân Mai                    |
| 10072     | Xã Quảng Bị                    |
| 10081     | Xã Trần Phú                    |
| 10096     | Xã Hòa Phú                     |
| 10114     | Xã Thanh Oai                   |
| 10126     | Xã Bình Minh                   |
| 10144     | Xã Tam Hưng                    |
| 10180     | Xã Dân Hòa                     |
| 10183     | Xã Thường Tín                  |
| 10210     | Xã Hồng Vân                    |
| 10231     | Xã Thượng Phúc                 |
| 10237     | Xã Chương Dương                |
| 10273     | Xã Phú Xuyên                   |
| 10279     | Xã Phượng Dực                  |
| 10330     | Xã Chuyên Mỹ                   |
| 10342     | Xã Đại Xuyên                   |
| 10354     | Xã Vân Đình                    |
| 10369     | Xã Ứng Thiên                   |
| 10402     | Xã Ứng Hòa                     |
| 10417     | Xã Hòa Xá                      |
| 10441     | Xã Mỹ Đức                      |
| 10459     | Xã Phúc Sơn                    |
| 10465     | Xã Hồng Sơn                    |
| 10489     | Xã Hương Sơn                   |

**04. TỈNH CAO BẰNG**

**(Tổng số đơn vị hành chính cấp xã: 56, gồm 53 xã, 03 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 01273     | Phường Thục Phán          |
| 01279     | Phường Nùng Trí Cao       |
| 01288     | Phường Tân Giang          |
| 01290     | Xã Bảo Lâm                |
| 01294     | Xã Lý Bôn                 |
| 01297     | Xã Nam Quang              |
| 01304     | Xã Quảng Lâm              |
| 01318     | Xã Yên Thổ                |
| 01321     | Xã Bảo Lạc                |
| 01324     | Xã Cốc Pàng               |
| 01327     | Xã Cô Ba                  |
| 01336     | Xã Khánh Xuân             |
| 01339     | Xã Xuân Trường            |
| 01351     | Xã Hưng Đạo               |
| 01354     | Xã Huy Giáp               |
| 01360     | Xã Sơn Lộ                 |
| 01363     | Xã Thông Nông             |
| 01366     | Xã Cần Yên                |
| 01387     | Xã Thanh Long             |
| 01392     | Xã Trường Hà              |
| 01393     | Xã Lũng Nặm               |
| 01414     | Xã Tổng Cọt               |
| 01438     | Xã Hà Quảng               |
| 01447     | Xã Trà Lĩnh               |
| 01456     | Xã Quang Hán              |
| 01465     | Xã Quang Trung            |
| 01477     | Xã Trùng Khánh            |
| 01489     | Xã Đình Phong             |
| 01501     | Xã Đàm Thủy               |
| 01525     | Xã Đoài Dương             |
| 01537     | Xã Lý Quốc                |
| 01552     | Xã Quang Long             |
| 01558     | Xã Hạ Lang                |
| 01561     | Xã Vinh Quý               |
| 01576     | Xã Quảng Uyên             |
| 01594     | Xã Độc Lập                |
| 01618     | Xã Hạnh Phúc              |
| 01636     | Xã Bế Văn Đàn             |
| 01648     | Xã Phục Hòa               |
| 01654     | Xã Hòa An                 |
| 01660     | Xã Nam Tuấn               |
| 01699     | Xã Nguyễn Huệ             |
| 01708     | Xã Bạch Đằng              |
| 01726     | Xã Nguyên Bình            |
| 01729     | Xã Tĩnh Túc               |
| 01738     | Xã Ca Thành               |
| 01747     | Xã Minh Tâm               |
| 01768     | Xã Phan Thanh             |
| 01774     | Xã Tam Kim                |
| 01777     | Xã Thành Công             |
| 01786     | Xã Đông Khê               |
| 01789     | Xã Canh Tân               |
| 01792     | Xã Kim Đồng               |
| 01795     | Xã Minh Khai              |
| 01807     | Xã Thạch An               |
| 01822     | Xã Đức Long               |

**08. TỈNH TUYÊN QUANG**

**(Tổng số đơn vị hành chính cấp xã: 124, gồm 117 xã, 07 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 00691     | Phường Hà Giang 2         |
| 00694     | Phường Hà Giang 1         |
| 02212     | Phường Nông Tiến          |
| 02215     | Phường Minh Xuân          |
| 02509     | Phường Mỹ Lâm             |
| 02512     | Phường An Tường           |
| 02524     | Phường Bình Thuận         |
| 00700     | Xã Ngọc Đường             |
| 00706     | Xã Phú Linh               |
| 00715     | Xã Lũng Cú                |
| 00721     | Xã Đồng Văn               |
| 00733     | Xã Sà Phìn                |
| 00745     | Xã Phó Bảng               |
| 00763     | Xã Lũng Phìn              |
| 00769     | Xã Mèo Vạc                |
| 00778     | Xã Sơn Vĩ                 |
| 00787     | Xã Sủng Máng              |
| 00802     | Xã Khâu Vai               |
| 00808     | Xã Tát Ngà                |
| 00817     | Xã Niêm Sơn               |
| 00820     | Xã Yên Minh               |
| 00829     | Xã Thắng Mố               |
| 00832     | Xã Bạch Đích              |
| 00847     | Xã Mậu Duệ                |
| 00859     | Xã Ngọc Long              |
| 00865     | Xã Đường Thượng           |
| 00871     | Xã Du Già                 |
| 00874     | Xã Quản Bạ                |
| 00883     | Xã Cán Tỷ                 |
| 00889     | Xã Nghĩa Thuận            |
| 00892     | Xã Tùng Vài               |
| 00901     | Xã Lùng Tám               |
| 00913     | Xã Vị Xuyên               |
| 00919     | Xã Minh Tân               |
| 00922     | Xã Thuận Hòa              |
| 00925     | Xã Tùng Bá                |
| 00928     | Xã Thanh Thủy             |
| 00937     | Xã Lao Chải               |
| 00952     | Xã Cao Bồ                 |
| 00958     | Xã Thượng Sơn             |
| 00967     | Xã Việt Lâm               |
| 00970     | Xã Linh Hồ                |
| 00976     | Xã Bạch Ngọc              |
| 00982     | Xã Minh Sơn               |
| 00985     | Xã Giáp Trung             |
| 00991     | Xã Bắc Mê                 |
| 00994     | Xã Minh Ngọc              |
| 01006     | Xã Yên Cường              |
| 01012     | Xã Đường Hồng             |
| 01021     | Xã Hoàng Su Phì           |
| 01024     | Xã Bản Máy                |
| 01033     | Xã Thàng Tín              |
| 01051     | Xã Tân Tiến               |
| 01057     | Xã Pờ Ly Ngài             |
| 01075     | Xã Nậm Dịch               |
| 01084     | Xã Hồ Thầu                |
| 01090     | Xã Thông Nguyên           |
| 01096     | Xã Pà Vầy Sủ              |
| 01108     | Xã Xín Mần                |
| 01117     | Xã Trung Thịnh            |
| 01141     | Xã Nấm Dẩn                |
| 01144     | Xã Quảng Nguyên           |
| 01147     | Xã Khuôn Lùng             |
| 01153     | Xã Bắc Quang              |
| 01156     | Xã Vĩnh Tuy               |
| 01165     | Xã Đồng Tâm               |
| 01171     | Xã Tân Quang              |
| 01180     | Xã Bằng Hành              |
| 01192     | Xã Liên Hiệp              |
| 01201     | Xã Hùng An                |
| 01216     | Xã Đồng Yên               |
| 01225     | Xã Tiên Nguyên            |
| 01234     | Xã Yên Thành              |
| 01237     | Xã Quang Bình             |
| 01243     | Xã Tân Trịnh              |
| 01246     | Xã Bằng Lang              |
| 01255     | Xã Xuân Giang             |
| 01261     | Xã Tiên Yên               |
| 02221     | Xã Nà Hang                |
| 02239     | Xã Thượng Nông            |
| 02245     | Xã Côn Lôn                |
| 02248     | Xã Yên Hoa                |
| 02260     | Xã Hồng Thái              |
| 02266     | Xã Lâm Bình               |
| 02269     | Xã Thượng Lâm             |
| 02287     | Xã Chiêm Hóa              |
| 02296     | Xã Bình An                |
| 02302     | Xã Minh Quang             |
| 02305     | Xã Trung Hà               |
| 02308     | Xã Tân Mỹ                 |
| 02317     | Xã Yên Lập                |
| 02320     | Xã Tân An                 |
| 02332     | Xã Kiên Đài               |
| 02350     | Xã Kim Bình               |
| 02353     | Xã Hòa An                 |
| 02359     | Xã Tri Phú                |
| 02365     | Xã Yên Nguyên             |
| 02374     | Xã Hàm Yên                |
| 02380     | Xã Bạch Xa                |
| 02392     | Xã Phù Lưu                |
| 02398     | Xã Yên Phú                |
| 02404     | Xã Bình Xa                |
| 02407     | Xã Thái Sơn               |
| 02419     | Xã Thái Hòa               |
| 02425     | Xã Hùng Đức               |
| 02434     | Xã Lực Hành               |
| 02437     | Xã Kiến Thiết             |
| 02449     | Xã Xuân Vân               |
| 02455     | Xã Hùng Lợi               |
| 02458     | Xã Trung Sơn              |
| 02470     | Xã Tân Long               |
| 02473     | Xã Yên Sơn                |
| 02494     | Xã Thái Bình              |
| 02530     | Xã Nhữ Khê                |
| 02536     | Xã Sơn Dương              |
| 02545     | Xã Tân Trào               |
| 02548     | Xã Bình Ca                |
| 02554     | Xã Minh Thanh             |
| 02572     | Xã Đông Thọ               |
| 02578     | Xã Tân Thanh              |
| 02608     | Xã Hồng Sơn               |
| 02611     | Xã Phú Lương              |
| 02620     | Xã Sơn Thủy               |
| 02623     | Xã Trường Sinh            |

**11. TỈNH ĐIỆN BIÊN**

**(Tổng số đơn vị hành chính cấp xã: 45, gồm 42 xã, 03 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 03127     | Phường Điện Biên Phủ      |
| 03151     | Phường Mường Lay          |
| 03334     | Phường Mường Thanh        |
| 03158     | Xã Sín Thầu               |
| 03160     | Xã Mường Nhé              |
| 03162     | Xã Nậm Kè                 |
| 03163     | Xã Mường Toong            |
| 03164     | Xã Quảng Lâm              |
| 03166     | Xã Mường Chà              |
| 03169     | Xã Nà Hỳ                  |
| 03172     | Xã Na Sang                |
| 03175     | Xã Chà Tở                 |
| 03176     | Xã Nà Bủng                |
| 03181     | Xã Mường Tùng             |
| 03193     | Xã Pa Ham                 |
| 03194     | Xã Nậm Nèn                |
| 03199     | Xã Si Pa Phìn             |
| 03202     | Xã Mường Pồn              |
| 03203     | Xã Na Son                 |
| 03208     | Xã Xa Dung                |
| 03214     | Xã Mường Luân             |
| 03217     | Xã Tủa Chùa               |
| 03220     | Xã Tủa Thàng              |
| 03226     | Xã Sín Chải               |
| 03241     | Xã Sính Phình             |
| 03244     | Xã Sáng Nhè               |
| 03253     | Xã Tuần Giáo              |
| 03256     | Xã Mường Ảng              |
| 03260     | Xã Pú Nhung               |
| 03268     | Xã Mường Mùn              |
| 03283     | Xã Chiềng Sinh            |
| 03295     | Xã Quài Tở                |
| 03301     | Xã Búng Lao               |
| 03313     | Xã Mường Lạn              |
| 03316     | Xã Nà Tấu                 |
| 03325     | Xã Mường Phăng            |
| 03328     | Xã Thanh Nưa              |
| 03349     | Xã Thanh Yên              |
| 03352     | Xã Thanh An               |
| 03356     | Xã Sam Mứn                |
| 03358     | Xã Núa Ngam               |
| 03368     | Xã Mường Nhà              |
| 03370     | Xã Pu Nhi                 |
| 03382     | Xã Phình Giàng            |
| 03385     | Xã Tìa Dình               |

**12. TỈNH LAI CHÂU**

**(Tổng số đơn vị hành chính cấp xã: 38, gồm 36 xã, 02 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 03388     | Phường Đoàn Kết           |
| 03408     | Phường Tân Phong          |
| 03390     | Xã Bình Lư                |
| 03394     | Xã Sin Suối Hồ            |
| 03405     | Xã Tả Lèng                |
| 03424     | Xã Bản Bo                 |
| 03430     | Xã Khun Há                |
| 03433     | Xã Bum Tở                 |
| 03434     | Xã Nậm Hàng               |
| 03439     | Xã Thu Lũm                |
| 03442     | Xã Pa Ủ                   |
| 03445     | Xã Mường Tè               |
| 03451     | Xã Mù Cả                  |
| 03460     | Xã Hua Bum                |
| 03463     | Xã Tà Tổng                |
| 03466     | Xã Bum Nưa                |
| 03472     | Xã Mường Mô               |
| 03478     | Xã Sìn Hồ                 |
| 03487     | Xã Lê Lợi                 |
| 03503     | Xã Pa Tần                 |
| 03508     | Xã Hồng Thu               |
| 03517     | Xã Nậm Tăm                |
| 03529     | Xã Tủa Sín Chải           |
| 03532     | Xã Pu Sam Cáp             |
| 03538     | Xã Nậm Mạ                 |
| 03544     | Xã Nậm Cuổi               |
| 03549     | Xã Phong Thổ              |
| 03562     | Xã Sì Lở Lầu              |
| 03571     | Xã Dào San                |
| 03583     | Xã Khổng Lào              |
| 03595     | Xã Than Uyên              |
| 03598     | Xã Tân Uyên               |
| 03601     | Xã Mường Khoa             |
| 03613     | Xã Nậm Sỏ                 |
| 03616     | Xã Pắc Ta                 |
| 03618     | Xã Mường Than             |
| 03637     | Xã Mường Kim              |
| 03640     | Xã Khoen On               |

**14. TỈNH SƠN LA**

**(Tổng số đơn vị hành chính cấp xã: 75, gồm 67 xã, 08 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 03646     | Phường Tô Hiệu            |
| 03664     | Phường Chiềng An          |
| 03670     | Phường Chiềng Cơi         |
| 03679     | Phường Chiềng Sinh        |
| 03979     | Phường Mộc Sơn            |
| 03980     | Phường Mộc Châu           |
| 03982     | Phường Thảo Nguyên        |
| 04033     | Phường Vân Sơn            |
| 03688     | Xã Mường Chiên            |
| 03694     | Xã Mường Giôn             |
| 03703     | Xã Quỳnh Nhai             |
| 03712     | Xã Mường Sại              |
| 03721     | Xã Thuận Châu             |
| 03724     | Xã Bình Thuận             |
| 03727     | Xã Mường É                |
| 03754     | Xã Chiềng La              |
| 03757     | Xã Mường Khiêng           |
| 03760     | Xã Mường Bám              |
| 03763     | Xã Long Hẹ                |
| 03781     | Xã Co Mạ                  |
| 03784     | Xã Nậm Lầu                |
| 03799     | Xã Muổi Nọi               |
| 03808     | Xã Mường La               |
| 03814     | Xã Chiềng Lao             |
| 03820     | Xã Ngọc Chiến             |
| 03847     | Xã Mường Bú               |
| 03850     | Xã Chiềng Hoa             |
| 03856     | Xã Bắc Yên                |
| 03862     | Xã Xím Vàng               |
| 03868     | Xã Tà Xùa                 |
| 03871     | Xã Pắc Ngà                |
| 03880     | Xã Tạ Khoa                |
| 03892     | Xã Chiềng Sại             |
| 03901     | Xã Suối Tọ                |
| 03907     | Xã Mường Cơi              |
| 03910     | Xã Phù Yên                |
| 03922     | Xã Gia Phù                |
| 03943     | Xã Mường Bang             |
| 03958     | Xã Tường Hạ               |
| 03961     | Xã Kim Bon                |
| 03970     | Xã Tân Phong              |
| 03985     | Xã Chiềng Sơn             |
| 03997     | Xã Tân Yên                |
| 04000     | Xã Đoàn Kết               |
| 04006     | Xã Song Khủa              |
| 04018     | Xã Tô Múa                 |
| 04045     | Xã Lóng Sập               |
| 04048     | Xã Vân Hồ                 |
| 04057     | Xã Xuân Nha               |
| 04075     | Xã Yên Châu               |
| 04078     | Xã Chiềng Hặc             |
| 04087     | Xã Yên Sơn                |
| 04096     | Xã Lóng Phiêng            |
| 04099     | Xã Phiêng Khoài           |
| 04105     | Xã Mai Sơn                |
| 04108     | Xã Chiềng Sung            |
| 04117     | Xã Mường Chanh            |
| 04123     | Xã Chiềng Mung            |
| 04132     | Xã Chiềng Mai             |
| 04136     | Xã Tà Hộc                 |
| 04144     | Xã Phiêng Cằm             |
| 04159     | Xã Phiêng Pằn             |
| 04168     | Xã Sông Mã                |
| 04171     | Xã Bó Sinh                |
| 04183     | Xã Mường Lầm              |
| 04186     | Xã Nậm Ty                 |
| 04195     | Xã Chiềng Sơ              |
| 04204     | Xã Chiềng Khoong          |
| 04210     | Xã Huổi Một               |
| 04219     | Xã Mường Hung             |
| 04222     | Xã Chiềng Khương          |
| 04228     | Xã Púng Bánh              |
| 04231     | Xã Sốp Cộp                |
| 04240     | Xã Mường Lèo              |
| 04246     | Xã Mường Lạn              |

**15. TỈNH LÀO CAI**

**(Tổng số đơn vị hành chính cấp xã: 99, gồm 89 xã, 10 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 02647     | Phường Lào Cai            |
| 02671     | Phường Cam Đường          |
| 03006     | Phường Sa Pa              |
| 04252     | Phường Yên Bái            |
| 04273     | Phường Nam Cường          |
| 04279     | Phường Văn Phú            |
| 04288     | Phường Nghĩa Lộ           |
| 04543     | Phường Âu Lâu             |
| 04663     | Phường Trung Tâm          |
| 04681     | Phường Cầu Thia           |
| 02680     | Xã Hợp Thành              |
| 02683     | Xã Bát Xát                |
| 02686     | Xã A Mú Sung              |
| 02695     | Xã Trịnh Tường            |
| 02701     | Xã Y Tý                   |
| 02707     | Xã Dền Sáng               |
| 02725     | Xã Bản Xèo                |
| 02728     | Xã Mường Hum              |
| 02746     | Xã Cốc San                |
| 02752     | Xã Pha Long               |
| 02761     | Xã Mường Khương           |
| 02782     | Xã Cao Sơn                |
| 02788     | Xã Bản Lầu                |
| 02809     | Xã Si Ma Cai              |
| 02824     | Xã Sín Chéng              |
| 02839     | Xã Bắc Hà                 |
| 02842     | Xã Tả Củ Tỷ               |
| 02848     | Xã Lùng Phình             |
| 02869     | Xã Bản Liền               |
| 02890     | Xã Bảo Nhai               |
| 02896     | Xã Cốc Lầu                |
| 02902     | Xã Phong Hải              |
| 02905     | Xã Bảo Thắng              |
| 02908     | Xã Tằng Loỏng             |
| 02923     | Xã Gia Phú                |
| 02926     | Xã Xuân Quang             |
| 02947     | Xã Bảo Yên                |
| 02953     | Xã Nghĩa Đô               |
| 02962     | Xã Xuân Hòa               |
| 02968     | Xã Thượng Hà              |
| 02989     | Xã Bảo Hà                 |
| 02998     | Xã Phúc Khánh             |
| 03004     | Xã Ngũ Chỉ Sơn            |
| 03013     | Xã Tả Phìn                |
| 03037     | Xã Tả Van                 |
| 03043     | Xã Mường Bo               |
| 03046     | Xã Bản Hồ                 |
| 03061     | Xã Võ Lao                 |
| 03076     | Xã Nậm Chày               |
| 03082     | Xã Văn Bàn                |
| 03085     | Xã Nậm Xé                 |
| 03091     | Xã Chiềng Ken             |
| 03103     | Xã Khánh Yên              |
| 03106     | Xã Dương Quỳ              |
| 03121     | Xã Minh Lương             |
| 04303     | Xã Lục Yên                |
| 04309     | Xã Lâm Thượng             |
| 04336     | Xã Tân Lĩnh               |
| 04342     | Xã Khánh Hòa              |
| 04345     | Xã Mường Lai              |
| 04363     | Xã Phúc Lợi               |
| 04375     | Xã Mậu A                  |
| 04381     | Xã Lâm Giang              |
| 04387     | Xã Châu Quế               |
| 04399     | Xã Đông Cuông             |
| 04402     | Xã Phong Dụ Hạ            |
| 04423     | Xã Phong Dụ Thượng        |
| 04429     | Xã Tân Hợp                |
| 04441     | Xã Xuân Ái                |
| 04450     | Xã Mỏ Vàng                |
| 04456     | Xã Mù Cang Chải           |
| 04462     | Xã Nậm Có                 |
| 04465     | Xã Khao Mang              |
| 04474     | Xã Lao Chải               |
| 04489     | Xã Chế Tạo                |
| 04492     | Xã Púng Luông             |
| 04498     | Xã Trấn Yên               |
| 04531     | Xã Quy Mông               |
| 04537     | Xã Lương Thịnh            |
| 04564     | Xã Việt Hồng              |
| 04576     | Xã Hưng Khánh             |
| 04585     | Xã Hạnh Phúc              |
| 04603     | Xã Tà Xi Láng             |
| 04606     | Xã Trạm Tấu               |
| 04609     | Xã Phình Hồ               |
| 04630     | Xã Tú Lệ                  |
| 04636     | Xã Gia Hội                |
| 04651     | Xã Sơn Lương              |
| 04660     | Xã Liên Sơn               |
| 04672     | Xã Văn Chấn               |
| 04693     | Xã Cát Thịnh              |
| 04699     | Xã Chấn Thịnh             |
| 04705     | Xã Thượng Bằng La         |
| 04711     | Xã Nghĩa Tâm              |
| 04714     | Xã Yên Bình               |
| 04717     | Xã Thác Bà                |
| 04726     | Xã Cảm Nhân               |
| 04744     | Xã Yên Thành              |
| 04750     | Xã Bảo Ái                 |

**19. TỈNH THÁI NGUYÊN**

**(Tổng số đơn vị hành chính cấp xã: 92, gồm 77 xã, 15 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 01840     | Phường Đức Xuân           |
| 01843     | Phường Bắc Kạn            |
| 05443     | Phường Phan Đình Phùng    |
| 05455     | Phường Quyết Thắng        |
| 05467     | Phường Gia Sàng           |
| 05482     | Phường Quan Triều         |
| 05500     | Phường Tích Lương         |
| 05518     | Phường Sông Công          |
| 05528     | Phường Bách Quang         |
| 05533     | Phường Bá Xuyên           |
| 05710     | Phường Linh Sơn           |
| 05857     | Phường Phúc Thuận         |
| 05860     | Phường Phổ Yên            |
| 05890     | Phường Vạn Xuân           |
| 05899     | Phường Trung Thành        |
| 01849     | Xã Phong Quang            |
| 01864     | Xã Bằng Thành             |
| 01879     | Xã Cao Minh               |
| 01882     | Xã Nghiên Loan            |
| 01894     | Xã Phúc Lộc               |
| 01906     | Xã Ba Bể                  |
| 01912     | Xã Chợ Rã                 |
| 01921     | Xã Thượng Minh            |
| 01933     | Xã Đồng Phúc              |
| 01936     | Xã Nà Phặc                |
| 01942     | Xã Bằng Vân               |
| 01954     | Xã Ngân Sơn               |
| 01957     | Xã Thượng Quan            |
| 01960     | Xã Hiệp Lực               |
| 01969     | Xã Phủ Thông              |
| 01981     | Xã Vĩnh Thông             |
| 02008     | Xã Cẩm Giàng              |
| 02014     | Xã Bạch Thông             |
| 02020     | Xã Chợ Đồn                |
| 02026     | Xã Nam Cường              |
| 02038     | Xã Quảng Bạch             |
| 02044     | Xã Yên Thịnh              |
| 02071     | Xã Nghĩa Tá               |
| 02083     | Xã Yên Phong              |
| 02086     | Xã Chợ Mới                |
| 02101     | Xã Thanh Mai              |
| 02104     | Xã Tân Kỳ                 |
| 02107     | Xã Thanh Thịnh            |
| 02116     | Xã Yên Bình               |
| 02143     | Xã Văn Lang               |
| 02152     | Xã Cường Lợi              |
| 02155     | Xã Na Rì                  |
| 02176     | Xã Trần Phú               |
| 02185     | Xã Côn Minh               |
| 02191     | Xã Xuân Dương             |
| 05488     | Xã Đại Phúc               |
| 05503     | Xã Tân Cương              |
| 05542     | Xã Lam Vỹ                 |
| 05551     | Xã Kim Phượng             |
| 05563     | Xã Phượng Tiến            |
| 05569     | Xã Định Hóa               |
| 05581     | Xã Trung Hội              |
| 05587     | Xã Bình Yên               |
| 05602     | Xã Phú Đình               |
| 05605     | Xã Bình Thành             |
| 05611     | Xã Phú Lương              |
| 05620     | Xã Yên Trạch              |
| 05632     | Xã Hợp Thành              |
| 05641     | Xã Vô Tranh               |
| 05662     | Xã Trại Cau               |
| 05665     | Xã Văn Lăng               |
| 05674     | Xã Quang Sơn              |
| 05680     | Xã Văn Hán                |
| 05692     | Xã Đồng Hỷ                |
| 05707     | Xã Nam Hòa                |
| 05716     | Xã Võ Nhai                |
| 05719     | Xã Sảng Mộc               |
| 05722     | Xã Nghinh Tường           |
| 05725     | Xã Thần Sa                |
| 05740     | Xã La Hiên                |
| 05746     | Xã Tràng Xá               |
| 05755     | Xã Dân Tiến               |
| 05773     | Xã Phú Xuyên              |
| 05776     | Xã Đức Lương              |
| 05788     | Xã Phú Lạc                |
| 05800     | Xã Phú Thịnh              |
| 05809     | Xã An Khánh               |
| 05818     | Xã La Bằng                |
| 05830     | Xã Đại Từ                 |
| 05845     | Xã Vạn Phú                |
| 05851     | Xã Quân Chu               |
| 05881     | Xã Thành Công             |
| 05908     | Xã Phú Bình               |
| 05917     | Xã Tân Khánh              |
| 05923     | Xã Tân Thành              |
| 05941     | Xã Điềm Thụy              |
| 05953     | Xã Kha Sơn                |

**20. TỈNH LẠNG SƠN**

**(Tổng số đơn vị hành chính cấp xã: 65, gồm 61 xã, 04 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 05977     | Phường Đông Kinh          |
| 05983     | Phường Lương Văn Tri      |
| 05986     | Phường Tam Thanh          |
| 06187     | Phường Kỳ Lừa             |
| 06001     | Xã Đoàn Kết               |
| 06004     | Xã Quốc Khánh             |
| 06019     | Xã Tân Tiến               |
| 06037     | Xã Kháng Chiến            |
| 06040     | Xã Thất Khê               |
| 06046     | Xã Tràng Định             |
| 06058     | Xã Quốc Việt              |
| 06073     | Xã Hoa Thám               |
| 06076     | Xã Quý Hòa                |
| 06079     | Xã Hồng Phong             |
| 06085     | Xã Thiện Hòa              |
| 06091     | Xã Thiện Thuật            |
| 06103     | Xã Thiện Long             |
| 06112     | Xã Bình Gia               |
| 06115     | Xã Tân Văn                |
| 06124     | Xã Na Sầm                 |
| 06148     | Xã Thụy Hùng              |
| 06151     | Xã Hội Hoan               |
| 06154     | Xã Văn Lãng               |
| 06172     | Xã Hoàng Văn Thụ          |
| 06184     | Xã Đồng Đăng              |
| 06196     | Xã Ba Sơn                 |
| 06211     | Xã Cao Lộc                |
| 06220     | Xã Công Sơn               |
| 06253     | Xã Văn Quan               |
| 06280     | Xã Điềm He                |
| 06286     | Xã Khánh Khê              |
| 06298     | Xã Yên Phúc               |
| 06313     | Xã Tri Lễ                 |
| 06316     | Xã Tân Đoàn               |
| 06325     | Xã Bắc Sơn                |
| 06337     | Xã Tân Tri                |
| 06349     | Xã Hưng Vũ                |
| 06364     | Xã Vũ Lễ                  |
| 06367     | Xã Vũ Lãng                |
| 06376     | Xã Nhất Hòa               |
| 06385     | Xã Hữu Lũng               |
| 06391     | Xã Yên Bình               |
| 06400     | Xã Hữu Liên               |
| 06415     | Xã Vân Nham               |
| 06427     | Xã Cai Kinh               |
| 06436     | Xã Thiện Tân              |
| 06445     | Xã Tân Thành              |
| 06457     | Xã Tuấn Sơn               |
| 06463     | Xã Chi Lăng               |
| 06475     | Xã Bằng Mạc               |
| 06481     | Xã Chiến Thắng            |
| 06496     | Xã Nhân Lý                |
| 06505     | Xã Vạn Linh               |
| 06517     | Xã Quan Sơn               |
| 06526     | Xã Na Dương               |
| 06529     | Xã Lộc Bình               |
| 06541     | Xã Mẫu Sơn                |
| 06565     | Xã Khuất Xá               |
| 06577     | Xã Thống Nhất             |
| 06601     | Xã Lợi Bác                |
| 06607     | Xã Xuân Dương             |
| 06613     | Xã Đình Lập               |
| 06616     | Xã Thái Bình              |
| 06625     | Xã Kiên Mộc               |
| 06637     | Xã Châu Sơn               |

**22. TỈNH QUẢNG NINH**

**(Tổng số đơn vị hành chính cấp xã: 54, gồm 22 xã, 30 phường, 02 đặc khu)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 06652     | Phường Hà Tu              |
| 06658     | Phường Cao Xanh           |
| 06661     | Phường Việt Hưng          |
| 06673     | Phường Bãi Cháy           |
| 06676     | Phường Hà Lầm             |
| 06685     | Phường Hồng Gai           |
| 06688     | Phường Hạ Long            |
| 06706     | Phường Tuần Châu          |
| 06709     | Phường Móng Cái 2         |
| 06712     | Phường Móng Cái 1         |
| 06736     | Phường Móng Cái 3         |
| 06760     | Phường Mông Dương         |
| 06778     | Phường Quang Hanh         |
| 06781     | Phường Cửa Ông            |
| 06793     | Phường Cẩm Phả            |
| 06811     | Phường Uông Bí            |
| 06820     | Phường Vàng Danh          |
| 06832     | Phường Yên Tử             |
| 07030     | Phường Hoành Bồ           |
| 07069     | Phường Mạo Khê            |
| 07081     | Phường Bình Khê           |
| 07090     | Phường An Sinh            |
| 07093     | Phường Đông Triều         |
| 07114     | Phường Hoàng Quế          |
| 07132     | Phường Quảng Yên          |
| 07135     | Phường Đông Mai           |
| 071.47    | Phượng Hiệp Hòa           |
| 07168     | Phường Hà An              |
| 07180     | Phường Liên Hòa           |
| 07183     | Phường Phong Cốc          |
| 06724     | Xã Hải Sơn                |
| 06733     | Xã Hải Ninh               |
| 06757     | Xã Vĩnh Thực              |
| 06799     | Xã Hải Hòa                |
| 06838     | Xã Bình Liêu              |
| 06841     | Xã Hoành Mô               |
| 06856     | Xã Lục Hồn                |
| 06862     | Xã Tiên Yên               |
| 06874     | Xã Điền Xá                |
| 06877     | Xã Đông Ngũ               |
| 06886     | Xã Hải Lạng               |
| 06895     | Xã Đầm Hà                 |
| 06913     | Xã Quảng Tân              |
| 06922     | Xã Quảng Hà               |
| 06931     | Xã Quảng Đức              |
| 06946     | Xã Đường Hoa              |
| 06967     | Xã Cái Chiên              |
| 06978     | Xã Ba Chẽ                 |
| 06979     | Xã Kỳ Thượng              |
| 06985     | Xã Lương Minh             |
| 07054     | Xã Quảng La               |
| 07060     | Xã Thống Nhất             |
| 06994     | Đặc khu Vân Đồn           |
| 07192     | Đặc khu Cô Tô             |

**24. TỈNH BẮC NINH**

**(Tổng số đơn vị hành chính cấp xã: 99, gồm 66 xã, 33 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 07210     | Phường Bắc Giang          |
| 07228     | Phường Đa Mai             |
| 07525     | Phường Chũ                |
| 07612     | Phường Phượng Sơn         |
| 07681     | Phường Yên Dũng           |
| 07682     | Phường Tân An             |
| 07696     | Phường Tiền Phong         |
| 07699     | Phường Tân Tiến           |
| 07738     | Phường Cảnh Thụy          |
| 07774     | Phường Tự Lạn             |
| 07777     | Phường Việt Yên           |
| 07795     | Phường Nếnh               |
| 07798     | Phường Vân Hà             |
| 09169     | Phường Vũ Ninh            |
| 09187     | Phường Kinh Bắc           |
| 09190     | Phường Võ Cường           |
| 09247     | Phường Quế Võ             |
| 09253     | Phường Nhân Hòa           |
| 09265     | Phường Phương Liễu        |
| 09286     | Phường Nam Sơn            |
| 09295     | Phường Bồng Lai           |
| 09301     | Phường Đào Viên           |
| 09325     | Phường Hạp Lĩnh           |
| 09367     | Phường Từ Sơn             |
| 09370     | Phường Tam Sơn            |
| 09379     | Phường Phù Khê            |
| 09385     | Phường Đồng Nguyên        |
| 09400     | Phường Thuận Thành        |
| 09409     | Phường Mão Điền           |
| 09427     | Phường Trí Quả            |
| 09430     | Phường Trạm Lộ            |
| 09433     | Phường Song Liễu          |
| 09445     | Phường Ninh Xá            |
| 07246     | Xã Xuân Lương             |
| 07264     | Xã Tam Tiến               |
| 07282     | Xã Đồng Kỳ                |
| 07288     | Xã Yên Thế                |
| 07294     | Xã Bố Hạ                  |
| 07306     | Xã Nhã Nam                |
| 07330     | Xã Phúc Hòa               |
| 07333     | Xã Quang Trung            |
| 07339     | Xã Tân Yên                |
| 07351     | Xã Ngọc Thiện             |
| 07375     | Xã Lạng Giang             |
| 07381     | Xã Tiên Lục               |
| 07399     | Xã Kép                    |
| 07420     | Xã Mỹ Thái                |
| 07432     | Xã Tân Dĩnh               |
| 07444     | Xã Lục Nam                |
| 07450     | Xã Đông Phú               |
| 07462     | Xã Bảo Đài                |
| 07486     | Xã Nghĩa Phương           |
| 07489     | Xã Trường Sơn             |
| 07492     | Xã Lục Sơn                |
| 07498     | Xã Bắc Lũng               |
| 07519     | Xã Cẩm Lý                 |
| 07531     | Xã Tân Sơn                |
| 07534     | Xã Sa Lý                  |
| 07537     | Xã Biên Sơn               |
| 07543     | Xã Sơn Hải                |
| 07552     | Xã Kiên Lao               |
| 07573     | Xã Biển Động              |
| 07582     | Xã Lục Ngạn               |
| 07594     | Xã Đèo Gia                |
| 07603     | Xã Nam Dương              |
| 07615     | Xã Sơn Động               |
| 07616     | Xã Tây Yên Tử             |
| 07621     | Xã Vân Sơn                |
| 07627     | Xã Đại Sơn                |
| 07642     | Xã Yên Định               |
| 07654     | Xã An Lạc                 |
| 07663     | Xã Tuấn Đạo               |
| 07672     | Xã Dương Hưu              |
| 07735     | Xã Đồng Việt              |
| 07822     | Xã Hoàng Vân              |
| 07840     | Xã Hiệp Hòa               |
| 07864     | Xã Hợp Thịnh              |
| 07870     | Xã Xuân Cẩm               |
| 09193     | Xã Yên Phong              |
| 09202     | Xã Tam Giang              |
| 09205     | Xã Yên Trung              |
| 09208     | Xã Tam Đa                 |
| 09238     | Xã Văn Môn                |
| 09292     | Xã Phù Lãng               |
| 09313     | Xã Chi Lăng               |
| 09319     | Xã Tiên Du                |
| 09334     | Xã Liên Bão               |
| 09340     | Xã Đại Đồng               |
| 09343     | Xã Tân Chi                |
| 09349     | Xã Phật Tích              |
| 09454     | Xã Gia Bình               |
| 09466     | Xã Cao Đức                |
| 09469     | Xã Đại Lai                |
| 09475     | Xã Nhân Thắng             |
| 09487     | Xã Đông Cứu               |
| 09496     | Xã Lương Tài              |
| 09499     | Xã Trung Kênh             |
| 09523     | Xã Trung Chính            |
| 09529     | Xã Lâm Thao               |

**25. TỈNH PHÚ THỌ**

**(Tổng số đơn vị hành chính cấp xã: 148, gồm 133 xã, 15 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 04792     | Phường Tân Hòa            |
| 04795     | Phường Hòa Bình           |
| 04828     | Phường Thống Nhất         |
| 04894     | Phường Kỳ Sơn             |
| 07894     | Phường Nông Trang         |
| 07900     | Phường Việt Trì           |
| 07909     | Phường Thanh Miếu         |
| 07918     | Phường Vân Phú            |
| 07942     | Phường Phú Thọ            |
| 07948     | Phường Âu Cơ              |
| 07954     | Phường Phong Châu         |
| 08707     | Phường Vĩnh Yên           |
| 08716     | Phường Vĩnh Phúc          |
| 08740     | Phường Phúc Yên           |
| 08746     | Phường Xuân Hòa           |
| 04831     | Xã Đà Bắc                 |
| 04846     | Xã Đức Nhàn               |
| 04849     | Xã Tân Pheo               |
| 04873     | Xã Quy Đức                |
| 04876     | Xã Cao Sơn                |
| 04891     | Xã Tiền Phong             |
| 04897     | Xã Thịnh Minh             |
| 04924     | Xã Lương Sơn              |
| 04960     | Xã Liên Sơn               |
| 04978     | Xã Kim Bôi                |
| 04990     | Xã Nật Sơn                |
| 05014     | Xã Mường Động             |
| 05047     | Xã Cao Dương              |
| 05068     | Xã Hợp Kim                |
| 05086     | Xã Dũng Tiến              |
| 05089     | Xã Cao Phong              |
| 05092     | Xã Thung Nai              |
| 05116     | Xã Mường Thàng            |
| 05128     | Xã Tân Lạc                |
| 05134     | Xã Mường Hoa              |
| 05152     | Xã Vân Sơn                |
| 05158     | Xã Mường Bi               |
| 05191     | Xã Toàn Thắng             |
| 05200     | Xã Mai Châu               |
| 05206     | Xã Tân Mai                |
| 05212     | Xã Pà Cò                  |
| 05245     | Xã Bao La                 |
| 05251     | Xã Mai Hạ                 |
| 05266     | Xã Lạc Sơn                |
| 05287     | Xã Mường Vang             |
| 05290     | Xã Nhân Nghĩa             |
| 05293     | Xã Thượng Cốc             |
| 05305     | Xã Yên Phú                |
| 05323     | Xã Quyết Thắng            |
| 05329     | Xã Ngọc Sơn               |
| 05347     | Xã Đại Đồng               |
| 05353     | Xã Yên Thủy               |
| 05362     | Xã Lạc Lương              |
| 05386     | Xã Yên Trị                |
| 05392     | Xã Lạc Thủy               |
| 05395     | Xã An Nghĩa               |
| 05425     | Xã An Bình                |
| 07969     | Xã Đoan Hùng              |
| 07996     | Xã Băng Luân              |
| 07999     | Xã Chí Đám                |
| 08023     | Xã Tây Cốc                |
| 08038     | Xã Chân Mộng              |
| 08053     | Xã Hạ Hòa                 |
| 08071     | Xã Đan Thượng             |
| 08110     | Xã Hiền Lương             |
| 08113     | Xã Yên Kỳ                 |
| 08134     | Xã Văn Lang               |
| 08143     | Xã Vĩnh Chân              |
| 08152     | Xã Thanh Ba               |
| 08173     | Xã Quảng Yên              |
| 08203     | Xã Hoàng Cương            |
| 08209     | Xã Đông Thành             |
| 08218     | Xã Chí Tiên               |
| 08227     | Xã Liên Minh              |
| 08230     | Xã Phù Ninh               |
| 08236     | Xã Phú Mỹ                 |
| 08245     | Xã Trạm Thản              |
| 08254     | Xã Dân Chủ                |
| 08275     | Xã Bình Phú               |
| 08290     | Xã Yên Lập                |
| 08296     | Xã Sơn Lương              |
| 08305     | Xã Xuân Viên              |
| 08311     | Xã Trung Sơn              |
| 08323     | Xã Thượng Long            |
| 08338     | Xã Minh Hòa               |
| 08341     | Xã Cẩm Khê                |
| 08344     | Xã Tiên Lương             |
| 08377     | Xã Vân Bán                |
| 08398     | Xã Phú Khê                |
| 08416     | Xã Hùng Việt              |
| 08431     | Xã Đồng Lương             |
| 08434     | Xã Tam Nông               |
| 08443     | Xã Hiền Quan              |
| 08467     | Xã Vạn Xuân               |
| 08479     | Xã Thọ Văn                |
| 08494     | Xã Lâm Thao               |
| 08500     | Xã Xuân Lũng              |
| 08515     | Xã Hy Cương               |
| 08521     | Xã Phùng Nguyên           |
| 08527     | Xã Bản Nguyên             |
| 08542     | Xã Thanh Sơn              |
| 08545     | Xã Thu Cúc                |
| 08560     | Xã Lai Đồng               |
| 08566     | Xã Tân Sơn                |
| 08584     | Xã Võ Miếu                |
| 08590     | Xã Xuân Đài               |
| 08593     | Xã Minh Đài               |
| 08611     | Xã Văn Miếu               |
| 08614     | Xã Cự Đồng                |
| 08620     | Xã Long Cốc               |
| 08632     | Xã Hương Cần              |
| 08635     | Xã Khả Cửu                |
| 08656     | Xã Yên Sơn                |
| 08662     | Xã Đào Xá                 |
| 08674     | Xã Thanh Thủy             |
| 08686     | Xã Tu Vũ                  |
| 08761     | Xã Lập Thạch              |
| 08770     | Xã Hợp Lý                 |
| 08773     | Xã Yên Lãng               |
| 08782     | Xã Hải Lựu                |
| 08788     | Xã Thái Hòa               |
| 08812     | Xã Liên Hòa               |
| 08824     | Xã Tam Sơn                |
| 08842     | Xã Tiên Lữ                |
| 08848     | Xã Sông Lô                |
| 08866     | Xã Sơn Đông               |
| 08869     | Xã Tam Dương              |
| 08872     | Xã Tam Dương Bắc          |
| 08896     | Xã Hoàng An               |
| 08905     | Xã Hội Thịnh              |
| 08911     | Xã Tam Đảo                |
| 08914     | Xã Đạo Trù                |
| 08923     | Xã Đại Đình               |
| 08935     | Xã Bình Nguyên            |
| 08944     | Xã Bình Tuyền             |
| 08950     | Xã Bình Xuyên             |
| 08971     | Xã Xuân Lãng              |
| 09025     | Xã Yên Lạc                |
| 09040     | Xã Tề Lỗ                  |
| 09043     | Xã Tam Hồng               |
| 09052     | Xã Nguyệt Đức             |
| 09064     | Xã Liên Châu              |
| 09076     | Xã Vĩnh Tường             |
| 09079     | Xã Vĩnh An                |
| 09100     | Xã Vĩnh Hưng              |
| 09106     | Xã Vĩnh Thành             |
| 09112     | Xã Thổ Tang               |
| 09154     | Xã Vĩnh Phú               |

**31. THÀNH PHỐ HẢI PHÒNG**

**(Tổng số đơn vị hành chính cấp xã: 114, gồm 67 xã, 45 phường, 02 đặc khu)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 10507     | Phường Thành Đông         |
| 10525     | Phường Hải Dương          |
| 10532     | Phường Lê Thanh Nghị      |
| 10537     | Phường Tân Hưng           |
| 10543     | Phường Việt Hòa           |
| 10546     | Phường Chí Linh           |
| 10549     | Phường Chu Văn An         |
| 10552     | Phường Nguyễn Trãi        |
| 10570     | Phường Trần Hưng Đạo      |
| 10573     | Phường Trần Nhân Tông     |
| 10603     | Phường Lê Đại Hành        |
| 10660     | Phường Ái Quốc            |
| 10675     | Phường Kinh Môn           |
| 10678     | Phường Bắc An Phụ         |
| 10714     | Phường Nhị Chiểu          |
| 10726     | Phường Phạm Sư Mạnh       |
| 10729     | Phường Trần Liễu          |
| 10744     | Phường Nguyễn Đại Năng    |
| 10837     | Phường Nam Đồng           |
| 10891     | Phường Tứ Minh            |
| 11002     | Phường Thạch Khôi         |
| 11311     | Phường Hồng Bàng          |
| 11329     | Phường Ngô Quyền          |
| 11359     | Phường Gia Viên           |
| 11383     | Phường Lê Chân            |
| 11407     | Phường An Biên            |
| 11411     | Phường Đông Hải           |
| 11413     | Phường Hải An             |
| 11443     | Phường Kiến An            |
| 11446     | Phường Phù Liễn           |
| 11455     | Phường Đồ Sơn             |
| 11473     | Phường Bạch Đằng          |
| 11488     | Phường Lưu Kiếm           |
| 11506     | Phường Lê Ích Mộc         |
| 11533     | Phường Hòa Bình           |
| 11542     | Phường Nam Triệu          |
| 11557     | Phường Thiên Hương        |
| 11560     | Phường Thủy Nguyên        |
| 11581     | Phường An Dương           |
| 11593     | Phường An Phong           |
| 11602     | Phường Hồng An            |
| 11617     | Phường An Hải             |
| 11689     | Phường Hưng Đạo           |
| 11692     | Phường Dương Kinh         |
| 11737     | Phường Nam Đồ Sơn         |
| 10606     | Xã Nam Sách               |
| 10615     | Xã Hợp Tiến               |
| 10633     | Xã Trần Phú               |
| 10642     | Xã Thái Tân               |
| 10645     | Xã An Phú                 |
| 10705     | Xã Nam An Phụ             |
| 10750     | Xã Phú Thái               |
| 10756     | Xã Lai Khê                |
| 10792     | Xã An Thành               |
| 10804     | Xã Kim Thành              |
| 10813     | Xã Thanh Hà               |
| 10816     | Xã Hà Bắc                 |
| 10843     | Xã Hà Nam                 |
| 10846     | Xã Hà Tây                 |
| 10882     | Xã Hà Đông                |
| 10888     | Xã Cẩm Giang              |
| 10903     | Xã Cẩm Giàng              |
| 10909     | Xã Tuệ Tĩnh               |
| 10930     | Xã Mao Điền               |
| 10945     | Xã Kẻ Sặt                 |
| 10966     | Xã Bình Giang             |
| 10972     | Xã Đường An               |
| 10993     | Xã Thượng Hồng            |
| 10999     | Xã Gia Lộc                |
| 11020     | Xã Yết Kiêu               |
| 11050     | Xã Gia Phúc               |
| 11065     | Xã Trường Tân             |
| 11074     | Xã Tứ Kỳ                  |
| 11086     | Xã Đại Sơn                |
| 11113     | Xã Tân Kỳ                 |
| 11131     | Xã Chí Minh               |
| 11140     | Xã Lạc Phượng             |
| 11146     | Xã Nguyên Giáp            |
| 11164     | Xã Vĩnh Lại               |
| 11167     | Xã Tân An                 |
| 11203     | Xã Ninh Giang             |
| 11218     | Xã Hồng Châu              |
| 11224     | Xã Khúc Thừa Dụ           |
| 11239     | Xã Thanh Miện             |
| 11242     | Xã Nguyễn Lương Bằng      |
| 11254     | Xã Bắc Thanh Miện         |
| 11257     | Xã Hải Hưng               |
| 11284     | Xã Nam Thanh Miện         |
| 11503     | Xã Việt Khê               |
| 11629     | Xã An Lão                 |
| 11635     | Xã An Trường              |
| 11647     | Xã An Quang               |
| 11668     | Xã An Khánh               |
| 11674     | Xã An Hưng                |
| 11680     | Xã Kiến Thụy              |
| 11713     | Xã Nghi Dương             |
| 11725     | Xã Kiến Minh              |
| 11728     | Xã Kiến Hưng              |
| 11749     | Xã Kiến Hải               |
| 11755     | Xã Tiên Lãng              |
| 11761     | Xã Quyết Thắng            |
| 11779     | Xã Tân Minh               |
| 11791     | Xã Tiên Minh              |
| 11806     | Xã Chấn Hưng              |
| 11809     | Xã Hùng Thắng             |
| 11824     | Xã Vĩnh Bảo               |
| 11836     | Xã Vĩnh Thịnh             |
| 11842     | Xã Vĩnh Thuận             |
| 11848     | Xã Vĩnh Hòa               |
| 11875     | Xã Vĩnh Hải               |
| 11887     | Xã Vĩnh Am                |
| 11911     | Xã Nguyễn Bỉnh Khiêm      |
| 11914     | Đặc khu Cát Hải           |
| 11948     | Đặc khu Bạch Long Vĩ      |

**33. TỈNH HƯNG YÊN**

**(Tổng số đơn vị hành chính cấp xã: 104, gồm 93 xã, 11 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 11953     | Phường Phố Hiến           |
| 11980     | Phường Hồng Châu          |
| 11983     | Phường Sơn Nam            |
| 12103     | Phường Mỹ Hào             |
| 12127     | Phường Thượng Hồng        |
| 12133     | Phường Đường Hào          |
| 12452     | Phường Trần Hưng Đạo      |
| 12454     | Phường Trần Lãm           |
| 12466     | Phường Vũ Phúc            |
| 12817     | Phường Trà Lý             |
| 13225     | Phường Thái Bình          |
| 11977     | Xã Tân Hưng               |
| 11992     | Xã Lạc Đạo                |
| 11995     | Xã Đại Đồng               |
| 12004     | Xã Như Quỳnh              |
| 12019     | Xã Văn Giang              |
| 12025     | Xã Phụng Công             |
| 12031     | Xã Nghĩa Trụ              |
| 12049     | Xã Mễ Sở                  |
| 12064     | Xã Nguyễn Văn Linh        |
| 12070     | Xã Hoàn Long              |
| 12073     | Xã Yên Mỹ                 |
| 12091     | Xã Việt Yên               |
| 12142     | Xã Ân Thi                 |
| 12148     | Xã Phạm Ngũ Lão           |
| 12166     | Xã Xuân Trúc              |
| 12184     | Xã Nguyễn Trãi            |
| 12196     | Xã Hồng Quang             |
| 12205     | Xã Khoái Châu             |
| 12223     | Xã Triệu Việt Vương       |
| 12238     | Xã Việt Tiến              |
| 12247     | Xã Châu Ninh              |
| 12271     | Xã Chí Minh               |
| 12280     | Xã Lương Bằng             |
| 12286     | Xã Nghĩa Dân              |
| 12313     | Xã Đức Hợp                |
| 12322     | Xã Hiệp Cường             |
| 12337     | Xã Hoàng Hoa Thám         |
| 12361     | Xã Tiên Hoa               |
| 12364     | Xã Tiên Lữ                |
| 12391     | Xã Quang Hưng             |
| 12406     | Xã Đoàn Đào               |
| 12424     | Xã Tiên Tiến              |
| 12427     | Xã Tống Trân              |
| 12472     | Xã Quỳnh Phụ              |
| 12499     | Xã A Sào                  |
| 12511     | Xã Minh Thọ               |
| 12517     | Xã Ngọc Lâm               |
| 12523     | Xã Phụ Dực                |
| 12526     | Xã Đồng Bằng              |
| 12532     | Xã Nguyễn Du              |
| 12577     | Xã Quỳnh An               |
| 12583     | Xã Tân Tiến               |
| 12586     | Xã Hưng Hà                |
| 12595     | Xã Ngự Thiên              |
| 12613     | Xã Long Hưng              |
| 12619     | Xã Diên Hà                |
| 12631     | Xã Thần Khê               |
| 12634     | Xã Tiên La                |
| 12676     | Xã Lê Quý Đôn             |
| 12685     | Xã Hồng Minh              |
| 12688     | Xã Đông Hưng              |
| 12694     | Xã Bắc Đông Hưng          |
| 12700     | Xã Bắc Tiên Hưng          |
| 12736     | Xã Đông Tiên Hưng         |
| 12745     | Xã Bắc Đông Quan          |
| 12754     | Xã Tiên Hưng              |
| 12763     | Xã Nam Tiên Hưng          |
| 12775     | Xã Nam Đông Hưng          |
| 12793     | Xã Đông Quan              |
| 12826     | Xã Thái Thụy              |
| 12850     | Xã Tây Thụy Anh           |
| 12859     | Xã Bắc Thụy Anh           |
| 12862     | Xã Đông Thụy Anh          |
| 12865     | Xã Thụy Anh               |
| 12904     | Xã Nam Thụy Anh           |
| 12916     | Xã Bắc Thái Ninh          |
| 12919     | Xã Tây Thái Ninh          |
| 12922     | Xã Thái Ninh              |
| 12943     | Xã Đông Thái Ninh         |
| 12961     | Xã Nam Thái Ninh          |
| 12970     | Xã Tiền Hải               |
| 12988     | Xã Đông Tiền Hải          |
| 13003     | Xã Đồng Châu              |
| 13021     | Xã Ái Quốc                |
| 13039     | Xã Tây Tiền Hải           |
| 13057     | Xã Nam Cường              |
| 13063     | Xã Nam Tiền Hải           |
| 13066     | Xã Hưng Phú               |
| 13075     | Xã Kiến Xương             |
| 13093     | Xã Trà Giang              |
| 13096     | Xã Bình Nguyên            |
| 13120     | Xã Lê Lợi                 |
| 13132     | Xã Quang Lịch             |
| 13141     | Xã Vũ Quý                 |
| 13159     | Xã Hồng Vũ                |
| 13183     | Xã Bình Thanh             |
| 13186     | Xã Bình Định              |
| 13192     | Xã Vũ Thư                 |
| 13219     | Xã Vạn Xuân               |
| 13222     | Xã Thư Trì                |
| 13246     | Xã Tân Thuận              |
| 13264     | Xã Thư Vũ                 |
| 13279     | Xã Vũ Tiên                |

**37. TỈNH NINH BÌNH**

**(Tổng số đơn vị hành chính cấp xã: 129, gồm 97 xã, 32 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 13285     | Phường Phủ Lý             |
| 13291     | Phường Phù Vân            |
| 13318     | Phường Châu Sơn           |
| 13324     | Phường Duy Tiên           |
| 13330     | Phường Duy Tân            |
| 13336     | Phường Duy Hà             |
| 13348     | Phường Đồng Văn           |
| 13363     | Phường Tiên Sơn           |
| 13366     | Phường Hà Nam             |
| 13384     | Phường Kim Bảng           |
| 13393     | Phường Lê Hồ              |
| 13396     | Phường Nguyễn Úy          |
| 13402     | Phường Kim Thanh          |
| 13420     | Phường Tam Chúc           |
| 13435     | Phường Lý Thường Kiệt     |
| 13444     | Phường Liêm Tuyền         |
| 13669     | Phường Nam Định           |
| 13684     | Phường Thiên Trường       |
| 13693     | Phường Đông A             |
| 13699     | Phường Thành Nam          |
| 13708     | Phường Mỹ Lộc             |
| 13777     | Phường Trường Thi         |
| 13972     | Phường Vị Khê             |
| 13984     | Phường Hồng Quang         |
| 14329     | Phường Hoa Lư             |
| 14359     | Phường Nam Hoa Lư         |
| 14362     | Phường Tam Điệp           |
| 14365     | Phường Trung Sơn          |
| 14371     | Phường Yên Sơn            |
| 14533     | Phường Tây Hoa Lư         |
| 14566     | Phường Đông Hoa Lư        |
| 14725     | Phường Yên Thắng          |
| 13456     | Xã Liêm Hà                |
| 13474     | Xã Tân Thanh              |
| 13483     | Xã Thanh Bình             |
| 13489     | Xã Thanh Lâm              |
| 13495     | Xã Thanh Liêm             |
| 13501     | Xã Bình Mỹ                |
| 13504     | Xã Bình Lục               |
| 13531     | Xã Bình Giang             |
| 13540     | Xã Bình An                |
| 13558     | Xã Bình Sơn               |
| 13573     | Xã Lý Nhân                |
| 13579     | Xã Bắc Lý                 |
| 13591     | Xã Nam Xang               |
| 13594     | Xã Trần Thương            |
| 13597     | Xã Vĩnh Trụ               |
| 13609     | Xã Nhân Hà                |
| 13627     | Xã Nam Lý                 |
| 13741     | Xã Vụ Bản                 |
| 13750     | Xã Minh Tân               |
| 13753     | Xã Hiển Khánh             |
| 13786     | Xã Liên Minh              |
| 13795     | Xã Ý Yên                  |
| 13807     | Xã Tân Minh               |
| 13822     | Xã Phong Doanh            |
| 13834     | Xã Vũ Dương               |
| 13864     | Xã Vạn Thắng              |
| 13870     | Xã Yên Cường              |
| 13879     | Xã Yên Đồng               |
| 13891     | Xã Nghĩa Hưng             |
| 13894     | Xã Rạng Đông              |
| 13900     | Xã Đồng Thịnh             |
| 13918     | Xã Nghĩa Sơn              |
| 13927     | Xã Hồng Phong             |
| 13939     | Xã Quỹ Nhất               |
| 13957     | Xã Nghĩa Lâm              |
| 13966     | Xã Nam Trực               |
| 13987     | Xã Nam Hồng               |
| 14005     | Xã Nam Ninh               |
| 14011     | Xã Nam Minh               |
| 14014     | Xã Nam Đồng               |
| 14026     | Xã Cổ Lễ                  |
| 14038     | Xã Ninh Giang             |
| 14053     | Xã Trực Ninh              |
| 14056     | Xã Cát Thành              |
| 14062     | Xã Quang Hưng             |
| 14071     | Xã Minh Thái              |
| 14077     | Xã Ninh Cường             |
| 14089     | Xã Xuân Trường            |
| 14095     | Xã Xuân Hồng              |
| 14104     | Xã Xuân Giang             |
| 14122     | Xã Xuân Hưng              |
| 14161     | Xã Giao Minh              |
| 14167     | Xã Giao Thủy              |
| 14179     | Xã Giao Hưng              |
| 14182     | Xã Giao Hòa               |
| 14194     | Xã Giao Bình              |
| 14203     | Xã Giao Phúc              |
| 14212     | Xã Giao Ninh              |
| 14215     | Xã Hải Hậu                |
| 14218     | Xã Hải Tiến               |
| 14221     | Xã Hải Thịnh              |
| 14236     | Xã Hải Anh                |
| 14248     | Xã Hải Hưng               |
| 14281     | Xã Hải An                 |
| 14287     | Xã Hải Quang              |
| 14308     | Xã Hải Xuân               |
| 14389     | Xã Gia Lâm                |
| 14401     | Xã Gia Tường              |
| 14404     | Xã Cúc Phương             |
| 14407     | Xã Phú Sơn                |
| 14428     | Xã Nho Quan               |
| 14434     | Xã Thanh Sơn              |
| 14452     | Xã Quỳnh Lưu              |
| 14458     | Xã Phú Long               |
| 14464     | Xã Gia Viễn               |
| 14482     | Xã Gia Hưng               |
| 14488     | Xã Gia Vân                |
| 14494     | Xã Gia Trấn               |
| 14500     | Xã Đại Hoàng              |
| 14524     | Xã Gia Phong              |
| 14560     | Xã Yên Khánh              |
| 14563     | Xã Khánh Thiện            |
| 14608     | Xã Khánh Trung            |
| 14611     | Xã Khánh Nhạc             |
| 14614     | Xã Khánh Hội              |
| 14620     | Xã Phát Diệm              |
| 14623     | Xã Bình Minh              |
| 14638     | Xã Kim Sơn                |
| 14647     | Xã Quang Thiện            |
| 14653     | Xã Chất Bình              |
| 14674     | Xã Lai Thành              |
| 14677     | Xã Định Hóa               |
| 14698     | Xã Kim Đông               |
| 14701     | Xã Yên Mô                 |
| 14728     | Xã Yên Từ                 |
| 14743     | Xã Yên Mạc                |
| 14746     | Xã Đồng Thái              |

**38. TỈNH THANH HÓA**

**(Tổng số đơn vị hành chính cấp xã: 166, gồm 147 xã, 19 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 14758     | Phường Hàm Rồng           |
| 14797     | Phường Hạc Thành          |
| 14812     | Phường Bỉm Sơn            |
| 14818     | Phường Quang Trung        |
| 15853     | Phường Đông Tiến          |
| 15925     | Phường Nguyệt Viên        |
| 16378     | Phường Đông Sơn           |
| 16417     | Phường Đông Quang         |
| 16516     | Phường Nam Sầm Sơn        |
| 16522     | Phường Quảng Phú          |
| 16531     | Phường Sầm Sơn            |
| 16561     | Phường Tĩnh Gia           |
| 16576     | Phường Ngọc Sơn           |
| 16594     | Phường Tân Dân            |
| 16597     | Phường Hải Lĩnh           |
| 16609     | Phường Đào Duy Từ         |
| 16624     | Phường Trúc Lâm           |
| 16645     | Phường Hải Bình           |
| 16654     | Phường Nghi Sơn           |
| 14845     | Xã Mường Lát              |
| 14848     | Xã Tam Chung              |
| 14854     | Xã Mường Lý               |
| 14857     | Xã Trung Lý               |
| 14860     | Xã Quang Chiểu            |
| 14863     | Xã Pù Nhi                 |
| 14864     | Xã Nhi Sơn                |
| 14866     | Xã Mường Chanh            |
| 14869     | Xã Hồi Xuân               |
| 14872     | Xã Trung Thành            |
| 14875     | Xã Trung Sơn              |
| 14878     | Xã Phú Lệ                 |
| 14890     | Xã Phú Xuân               |
| 14896     | Xã Hiền Kiệt              |
| 14902     | Xã Nam Xuân               |
| 14908     | Xã Thiên Phủ              |
| 14923     | Xã Bá Thước               |
| 14932     | Xã Điền Quang             |
| 14950     | Xã Điền Lư                |
| 14953     | Xã Quý Lương              |
| 14956     | Xã Pù Luông               |
| 14959     | Xã Cổ Lũng                |
| 14974     | Xã Văn Nho                |
| 14980     | Xã Thiết Ống              |
| 15001     | Xã Trung Hạ               |
| 15007     | Xã Tam Thanh              |
| 15010     | Xã Sơn Thủy               |
| 15013     | Xã Na Mèo                 |
| 15016     | Xã Quan Sơn               |
| 15019     | Xã Tam Lư                 |
| 15022     | Xã Sơn Điện               |
| 15025     | Xã Mường Mìn              |
| 15031     | Xã Yên Khương             |
| 15034     | Xã Yên Thắng              |
| 15043     | Xã Giao An                |
| 15049     | Xã Văn Phú                |
| 15055     | Xã Linh Sơn               |
| 15058     | Xã Đồng Lương             |
| 15061     | Xã Ngọc Lặc               |
| 15085     | Xã Thạch Lập              |
| 15091     | Xã Ngọc Liên              |
| 15106     | Xã Nguyệt Ấn              |
| 15112     | Xã Kiên Thọ               |
| 15124     | Xã Minh Sơn               |
| 15127     | Xã Cẩm Thủy               |
| 15142     | Xã Cẩm Thạch              |
| 15148     | Xã Cẩm Tú                 |
| 15163     | Xã Cẩm Vân                |
| 15178     | Xã Cẩm Tân                |
| 15187     | Xã Kim Tân                |
| 15190     | Xã Vân Du                 |
| 15199     | Xã Thạch Quảng            |
| 15211     | Xã Thạch Bình             |
| 15229     | Xã Thành Vinh             |
| 15250     | Xã Ngọc Trạo              |
| 15271     | Xã Hà Trung               |
| 15274     | Xã Hà Long                |
| 15286     | Xã Hoạt Giang             |
| 15298     | Xã Lĩnh Toại              |
| 15316     | Xã Tống Sơn               |
| 15349     | Xã Vĩnh Lộc               |
| 15361     | Xã Tây Đô                 |
| 15382     | Xã Biện Thượng            |
| 15409     | Xã Yên Phú                |
| 15412     | Xã Quý Lộc                |
| 15421     | Xã Yên Trường             |
| 15442     | Xã Yên Ninh               |
| 15448     | Xã Định Hòa               |
| 15457     | Xã Định Tân               |
| 15469     | Xã Yên Định               |
| 15499     | Xã Thọ Xuân               |
| 15505     | Xã Thọ Long               |
| 15520     | Xã Xuân Hòa               |
| 15544     | Xã Lam Sơn                |
| 15553     | Xã Sao Vàng               |
| 15568     | Xã Thọ Lập                |
| 15574     | Xã Xuân Tín               |
| 15592     | Xã Xuân Lập               |
| 15607     | Xã Bát Mọt                |
| 15610     | Xã Yên Nhân               |
| 15622     | Xã Vạn Xuân               |
| 15628     | Xã Lương Sơn              |
| 15634     | Xã Luận Thành             |
| 15643     | Xã Thắng Lộc              |
| 15646     | Xã Thường Xuân            |
| 15658     | Xã Xuân Chinh             |
| 15661     | Xã Tân Thành              |
| 15664     | Xã Triệu Sơn              |
| 15667     | Xã Thọ Bình               |
| 15682     | Xã Hợp Tiến               |
| 15715     | Xã Tân Ninh               |
| 15724     | Xã Đồng Tiến              |
| 15754     | Xã Thọ Ngọc               |
| 15763     | Xã Thọ Phú                |
| 15766     | Xã An Nông                |
| 15772     | Xã Thiệu Hóa              |
| 15778     | Xã Thiệu Tiến             |
| 15796     | Xã Thiệu Quang            |
| 15820     | Xã Thiệu Toán             |
| 15835     | Xã Thiệu Trung            |
| 15865     | Xã Hoằng Hóa              |
| 15880     | Xã Hoằng Giang            |
| 15889     | Xã Hoằng Phú              |
| 15910     | Xã Hoằng Sơn              |
| 15961     | Xã Hoằng Lộc              |
| 15976     | Xã Hoằng Châu             |
| 15991     | Xã Hoằng Tiến             |
| 16000     | Xã Hoằng Thanh            |
| 16012     | Xã Hậu Lộc                |
| 16021     | Xã Triệu Lộc              |
| 16033     | Xã Đông Thành             |
| 16072     | Xã Hoa Lộc                |
| 16078     | Xã Vạn Lộc                |
| 16093     | Xã Nga Sơn                |
| 16108     | Xã Tân Tiến               |
| 16114     | Xã Nga Thắng              |
| 16138     | Xã Hồ Vương               |
| 16144     | Xã Nga An                 |
| 16171     | Xã Ba Đình                |
| 16174     | Xã Như Xuân               |
| 16177     | Xã Xuân Bình              |
| 16186     | Xã Hóa Quỳ                |
| 16213     | Xã Thanh Phong            |
| 16222     | Xã Thanh Quân             |
| 16225     | Xã Thượng Ninh            |
| 16228     | Xã Như Thanh              |
| 16234     | Xã Xuân Du                |
| 16249     | Xã Mậu Lâm                |
| 16258     | Xã Xuân Thái              |
| 16264     | Xã Yên Thọ                |
| 16273     | Xã Thanh Kỳ               |
| 16279     | Xã Nông Cống              |
| 16297     | Xã Trung Chính            |
| 16309     | Xã Thắng Lợi              |
| 16342     | Xã Thăng Bình             |
| 16348     | Xã Trường Văn             |
| 16363     | Xã Tượng Lĩnh             |
| 16369     | Xã Công Chính             |
| 16438     | Xã Lưu Vệ                 |
| 16480     | Xã Quảng Yên              |
| 16489     | Xã Quảng Chính            |
| 16498     | Xã Quảng Ngọc             |
| 16540     | Xã Quảng Ninh             |
| 16543     | Xã Quảng Bình             |
| 16549     | Xã Tiên Trang             |
| 16591     | Xã Các Sơn                |
| 16636     | Xã Trường Lâm             |

**40. TỈNH NGHỆ AN**

**(Tổng số đơn vị hành chính cấp xã: 130, gồm 119 xã, 11 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 16681     | Phường Thành Vinh         |
| 16690     | Phường Trường Vinh        |
| 16702     | Phường Vinh Phú           |
| 16708     | Phường Vinh Lộc           |
| 16732     | Phường Cửa Lò             |
| 16939     | Phường Thái Hòa           |
| 17011     | Phường Tây Hiếu           |
| 17110     | Phường Hoàng Mai          |
| 17125     | Phường Quỳnh Mai          |
| 17128     | Phường Tân Mai            |
| 17920     | Phường Vinh Hưng          |
| 16738     | Xã Quế Phong              |
| 16744     | Xã Thông Thụ              |
| 16750     | Xã Tiền Phong             |
| 16756     | Xã Tri Lễ                 |
| 16774     | Xã Mường Quàng            |
| 16777     | Xã Quỳ Châu               |
| 16792     | Xã Châu Tiến              |
| 16801     | Xã Hùng Chân              |
| 16804     | Xã Châu Bình              |
| 16813     | Xã Mường Xén              |
| 16816     | Xã Mỹ Lý                  |
| 16819     | Xã Bắc Lý                 |
| 16822     | Xã Keng Đu                |
| 16828     | Xã Huồi Tụ                |
| 16831     | Xã Mường Lống             |
| 16834     | Xã Na Loi                 |
| 16837     | Xã Nậm Cắn                |
| 16849     | Xã Hữu Kiệm               |
| 16855     | Xã Chiêu Lưu              |
| 16858     | Xã Mường Típ              |
| 16870     | Xã Na Ngoi                |
| 16876     | Xã Tương Dương            |
| 16882     | Xã Nhôn Mai               |
| 16885     | Xã Hữu Khuông             |
| 16903     | Xã Nga My                 |
| 16906     | Xã Lượng Minh             |
| 16909     | Xã Yên Hòa                |
| 16912     | Xã Yên Na                 |
| 16933     | Xã Tam Quang              |
| 16936     | Xã Tam Thái               |
| 16941     | Xã Nghĩa Đàn              |
| 16951     | Xã Nghĩa Lâm              |
| 16969     | Xã Nghĩa Thọ              |
| 16972     | Xã Nghĩa Hưng             |
| 16975     | Xã Nghĩa Mai              |
| 17017     | Xã Đông Hiếu              |
| 17029     | Xã Nghĩa Lộc              |
| 17032     | Xã Nghĩa Khánh            |
| 17035     | Xã Quỳ Hợp                |
| 17044     | Xã Châu Hồng              |
| 17056     | Xã Châu Lộc               |
| 17059     | Xã Tam Hợp                |
| 17071     | Xã Minh Hợp               |
| 17077     | Xã Mường Ham              |
| 17089     | Xã Mường Chọng            |
| 17143     | Xã Quỳnh Văn              |
| 17149     | Xã Quỳnh Tam              |
| 17170     | Xã Quỳnh Sơn              |
| 17176     | Xã Quỳnh Anh              |
| 17179     | Xã Quỳnh Lưu              |
| 17212     | Xã Quỳnh Phú              |
| 17224     | Xã Quỳnh Thắng            |
| 17230     | Xã Bình Chuẩn             |
| 17239     | Xã Mậu Thạch              |
| 17242     | Xã Cam Phục               |
| 17248     | Xã Châu Khê               |
| 17254     | Xã Con Cuông              |
| 17263     | Xã Môn Sơn                |
| 17266     | Xã Tân Kỳ                 |
| 17272     | Xã Tân Phú                |
| 17278     | Xã Giai Xuân              |
| 17284     | Xã Nghĩa Đồng             |
| 17287     | Xã Tiên Đồng              |
| 17305     | Xã Tân An                 |
| 17326     | Xã Nghĩa Hành             |
| 17329     | Xã Anh Sơn                |
| 17335     | Xã Thành Bình Thọ         |
| 17344     | Xã Nhân Hòa               |
| 17357     | Xã Vĩnh Tường             |
| 17365     | Xã Anh Sơn Đông           |
| 17380     | Xã Yên Xuân               |
| 17395     | Xã Hùng Châu              |
| 17416     | Xã Đức Châu               |
| 17419     | Xã Hải Châu               |
| 17443     | Xã Quảng Châu             |
| 17464     | Xã Diễn Châu              |
| 17476     | Xã Minh Châu              |
| 17479     | Xã An Châu                |
| 17488     | Xã Tân Châu               |
| 17506     | Xã Yên Thành              |
| 17515     | Xã Bình Minh              |
| 17521     | Xã Quang Đồng             |
| 17524     | Xã Giai Lạc               |
| 17530     | Xã Đông Thành             |
| 17560     | Xã Vân Du                 |
| 17569     | Xã Quan Thành             |
| 17605     | Xã Hợp Minh               |
| 17611     | Xã Vân Tụ                 |
| 17623     | Xã Bạch Ngọc              |
| 17641     | Xã Lương Sơn              |
| 17662     | Xã Đô Lương               |
| 17677     | Xã Văn Hiến               |
| 17689     | Xã Thuần Trung            |
| 17707     | Xã Bạch Hà                |
| 17713     | Xã Đại Đồng               |
| 17722     | Xã Hạnh Lâm               |
| 17728     | Xã Cát Ngạn               |
| 17743     | Xã Tam Đồng               |
| 17759     | Xã Sơn Lâm                |
| 17770     | Xã Hoa Quân               |
| 17779     | Xã Xuân Lâm               |
| 17791     | Xã Kim Bảng               |
| 17818     | Xã Bích Hào               |
| 17827     | Xã Nghi Lộc               |
| 17833     | Xã Hải Lộc                |
| 17842     | Xã Thần Lĩnh              |
| 17854     | Xã Văn Kiều               |
| 17857     | Xã Phúc Lộc               |
| 17866     | Xã Trung Lộc              |
| 17878     | Xã Đông Lộc               |
| 17935     | Xã Nam Đàn                |
| 17944     | Xã Đại Huệ                |
| 17950     | Xã Vạn An                 |
| 17971     | Xã Kim Liên               |
| 17989     | Xã Thiên Nhẫn             |
| 18001     | Xã Hưng Nguyên            |
| 18007     | Xã Yên Trung              |
| 18028     | Xã Hưng Nguyên Nam        |
| 18040     | Xã Lam Thành              |

**42. TỈNH HÀ TĨNH**

**(Tổng số đơn vị hành chính cấp xã: 69, gồm 60 xã, 09 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 18073     | Phường Thành Sen          |
| 18100     | Phường Trần Phú           |
| 18115     | Phường Bắc Hồng Lĩnh      |
| 18118     | Phường Nam Hồng Lĩnh      |
| 18652     | Phường Hà Huy Tập         |
| 18754     | Phường Sông Trí           |
| 18781     | Phường Hải Ninh           |
| 18823     | Phường Vũng Áng           |
| 18832     | Phường Hoành Sơn          |
| 18133     | Xã Hương Sơn              |
| 18160     | Xã Sơn Hồng               |
| 18163     | Xã Sơn Tiến               |
| 18172     | Xã Sơn Tây                |
| 18184     | Xã Sơn Giang              |
| 18196     | Xã Sơn Kim 1              |
| 18199     | Xã Sơn Kim 2              |
| 18202     | Xã Tứ Mỹ                  |
| 18223     | Xã Kim Hoa                |
| 18229     | Xã Đức Thọ                |
| 18244     | Xã Đức Minh               |
| 18262     | Xã Đức Quang              |
| 18277     | Xã Đức Thịnh              |
| 18304     | Xã Đức Đồng               |
| 18313     | Xã Vũ Quang               |
| 18322     | Xã Mai Hoa                |
| 18328     | Xã Thượng Đức             |
| 18352     | Xã Nghi Xuân              |
| 18364     | Xã Đan Hải                |
| 18373     | Xã Tiên Điền              |
| 18394     | Xã Cổ Đạm                 |
| 18406     | Xã Can Lộc                |
| 18409     | Xã Hồng Lộc               |
| 18418     | Xã Tùng Lộc               |
| 18436     | Xã Trường Lưu             |
| 18466     | Xã Gia Hanh               |
| 18481     | Xã Xuân Lộc               |
| 18484     | Xã Đồng Lộc               |
| 18496     | Xã Hương Khê              |
| 18502     | Xã Hà Linh                |
| 18523     | Xã Hương Bình             |
| 18532     | Xã Hương Phố              |
| 18544     | Xã Hương Xuân             |
| 18547     | Xã Phúc Trạch             |
| 18550     | Xã Hương Đô               |
| 18562     | Xã Thạch Hà               |
| 18568     | Xã Lộc Hà                 |
| 18583     | Xã Mai Phụ                |
| 18586     | Xã Đông Kinh              |
| 18601     | Xã Việt Xuyên             |
| 18604     | Xã Thạch Khê              |
| 18619     | Xã Đồng Tiến              |
| 18628     | Xã Thạch Lạc              |
| 18634     | Xã Toàn Lưu               |
| 18667     | Xã Thạch Xuân             |
| 18673     | Xã Cẩm Xuyên              |
| 18676     | Xã Thiên Cầm              |
| 18682     | Xã Yên Hòa                |
| 18685     | Xã Cẩm Bình               |
| 18736     | Xã Cẩm Hưng               |
| 18739     | Xã Cẩm Duệ                |
| 18742     | Xã Cẩm Trung              |
| 18748     | Xã Cẩm Lạc                |
| 18766     | Xã Kỳ Xuân                |
| 18775     | Xã Kỳ Anh                 |
| 18787     | Xã Kỳ Văn                 |
| 18790     | Xã Kỳ Khang               |
| 18814     | Xã Kỳ Hoa                 |
| 18838     | Xã Kỳ Lạc                 |
| 18844     | Xã Kỳ Thượng              |

**44. TỈNH QUẢNG TRỊ**

**(Tổng số đơn vị hành chính cấp xã: 78, gồm 69 xã, 08 phường, 01 đặc khu)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 18859     | Phường Đồng Thuận         |
| 18871     | Phường Đồng Sơn           |
| 18880     | Phường Đồng Hới           |
| 19009     | Phường Ba Đồn             |
| 19066     | Phường Bắc Gianh          |
| 19333     | Phường Đông Hà            |
| 19351     | Phường Nam Đông Hà        |
| 19360     | Phường Quảng Trị          |
| 18901     | Xã Minh Hóa               |
| 18904     | Xã Dân Hóa                |
| 18919     | Xã Tân Thành              |
| 18922     | Xã Kim Điền               |
| 18943     | Xã Kim Phú                |
| 18949     | Xã Đồng Lê                |
| 18952     | Xã Tuyên Sơn              |
| 18958     | Xã Tuyên Lâm              |
| 18985     | Xã Tuyên Phú              |
| 18991     | Xã Tuyên Bình             |
| 18997     | Xã Tuyên Hóa              |
| 19021     | Xã Phú Trạch              |
| 19030     | Xã Trung Thuần            |
| 19033     | Xã Hòa Trạch              |
| 19051     | Xã Tân Gianh              |
| 19057     | Xã Quảng Trạch            |
| 19075     | Xã Nam Ba Đồn             |
| 19093     | Xã Nam Gianh              |
| 19111     | Xã Hoàn Lão               |
| 19126     | Xã Bắc Trạch              |
| 19138     | Xã Phong Nha              |
| 19141     | Xã Bố Trạch               |
| 19147     | Xã Thượng Trạch           |
| 19159     | Xã Đông Trạch             |
| 19198     | Xã Nam Trạch              |
| 19204     | Xã Trường Sơn             |
| 19207     | Xã Quảng Ninh             |
| 19225     | Xã Ninh Châu              |
| 19237     | Xã Trường Ninh            |
| 19246     | Xã Lệ Ninh                |
| 19249     | Xã Lệ Thủy                |
| 19255     | Xã Cam Hồng               |
| 19288     | Xã Sen Ngư                |
| 19291     | Xã Tân Mỹ                 |
| 19309     | Xã Trường Phú             |
| 19318     | Xã Kim Ngân               |
| 19363     | Xã Vĩnh Linh              |
| 19366     | Xã Bến Quan               |
| 19372     | Xã Vĩnh Hoàng             |
| 19405     | Xã Vĩnh Thủy              |
| 19414     | Xã Cửa Tùng               |
| 19429     | Xã Khe Sanh               |
| 19432     | Xã Lao Bảo                |
| 19435     | Xã Hướng Lập              |
| 19441     | Xã Hướng Phùng            |
| 19462     | Xã Tân Lập                |
| 19483     | Xã A Dơi                  |
| 19489     | Xã Lìa                    |
| 19495     | Xã Gio Linh               |
| 19496     | Xã Cửa Việt               |
| 19501     | Xã Bến Hải                |
| 19537     | Xã Cồn Tiên               |
| 19555     | Xã Hướng Hiệp             |
| 19564     | Xã Đakrông                |
| 19567     | Xã Ba Lòng                |
| 19588     | Xã Tà Rụt                 |
| 19594     | Xã La Lay                 |
| 19597     | Xã Cam Lộ                 |
| 19603     | Xã Hiếu Giang             |
| 19624     | Xã Triệu Phong            |
| 19639     | Xã Nam Cửa Việt           |
| 19645     | Xã Triệu Bình             |
| 19654     | Xã Triệu Cơ               |
| 19669     | Xã Ái Tử                  |
| 19681     | Xã Diên Sanh              |
| 19699     | Xã Vĩnh Định              |
| 19702     | Xã Hải Lăng               |
| 19735     | Xã Nam Hải Lăng           |
| 19741     | Xã Mỹ Thủy                |
| 19742     | Đặc khu Cồn Cỏ            |

**46. THÀNH PHỐ HUẾ**

**(Tổng số đơn vị hành chính cấp xã: 40, gồm 19 xã, 21 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 19753     | Phường Phú Xuân           |
| 19774     | Phường Kim Long           |
| 19777     | Phường Vỹ Dạ              |
| 19789     | Phường Thuận Hóa          |
| 19804     | Phường Hương An           |
| 19813     | Phương Thủy Xuân          |
| 19815     | Phường An Cựu             |
| 19819     | Phường Phong Điền         |
| 19828     | Phường Phong Phú          |
| 19831     | Phường Phong Dinh         |
| 19858     | Phường Phong Thái         |
| 19873     | Phường Phong Quảng        |
| 19900     | Phường Thuận An           |
| 19909     | Phường Dương Nỗ           |
| 19930     | Phường Mỹ Thượng          |
| 19960     | Phường Phú Bài            |
| 19969     | Phường Thanh Thủy         |
| 19975     | Phường Hương Thủy         |
| 19996     | Phường Hương Trà          |
| 20014     | Phường Hóa Châu           |
| 20017     | Phường Kim Trà            |
| 19867     | Xã Quảng Điền             |
| 19885     | Xã Đan Điền               |
| 19918     | Xã Phú Hồ                 |
| 19942     | Xã Phú Vang               |
| 19945     | Xã Phú Vinh               |
| 20035     | Xã Bình Điền              |
| 20044     | Xã A Lưới 2               |
| 20050     | Xã A Lưới 5               |
| 20056     | Xã A Lưới 1               |
| 20071     | Xã A Lưới 3               |
| 20101     | Xã A Lưới 4               |
| 20107     | Xã Phú Lộc                |
| 20122     | Xã Vinh Lộc               |
| 20131     | Xã Hưng Lộc               |
| 20137     | Xã Chân Mây-Lăng Cô       |
| 20140     | Xã Lộc An                 |
| 20161     | Xã Khe Tre                |
| 20179     | Xã Nam Đông               |
| 20182     | Xã Long Quảng             |

**48. THÀNH PHỐ ĐÀ NẴNG**

**(Tổng số đơn vị hành chính cấp xã: 94, gồm 70 xã, 23 phường, 01 đặc khu)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 20194     | Phường Hải Vân            |
| 20197     | Phường Liên Chiểu         |
| 20200     | Phường Hòa Khánh          |
| 20209     | Phường Thanh Khê          |
| 20242     | Phường Hải Châu           |
| 20257     | Phường Hòa Cường          |
| 20260     | Phường Cẩm Lệ             |
| 20263     | Phường Sơn Trà            |
| 20275     | Phường An Hải             |
| 20285     | Phường Ngũ Hành Sơn       |
| 20305     | Phường An Khê             |
| 20314     | Phường Hòa Xuân           |
| 20335     | Phường Bàn Thạch          |
| 20341     | Phường Tam Kỳ             |
| 20350     | Phường Hương Trà          |
| 20356     | Phường Quảng Phú          |
| 20401     | Phường Hội An Tây         |
| 20410     | Phường Hội An             |
| 20413     | Phường Hội An Đông        |
| 20551     | Phường Điện Bàn           |
| 20557     | Phường Điện Bàn Bắc       |
| 20575     | Phường An Thắng           |
| 20579     | Phường Điện Bàn Đông      |
| 20308     | Xã Bà Nà                  |
| 20320     | Xã Hòa Vang               |
| 20332     | Xã Hòa Tiến               |
| 20364     | Xã Chiến Đàn              |
| 20380     | Xã Tây Hồ                 |
| 20392     | Xã Phú Ninh               |
| 20434     | Xã Tân Hiệp               |
| 20443     | Xã Hùng Sơn               |
| 20455     | Xã Tây Giang              |
| 20458     | Xã A vương                |
| 20467     | Xã Đông Giang             |
| 20476     | Xã Sông Kôn               |
| 20485     | Xã Sông Vàng              |
| 20494     | Xã Bến Hiên               |
| 20500     | Xã Đại Lộc                |
| 20506     | Xã Thượng Đức             |
| 20515     | Xã Hà Nha                 |
| 20539     | Xã Vu Gia                 |
| 20542     | Xã Phú Thuận              |
| 20569     | Xã Điện Bàn Tây           |
| 20587     | Xã Gò Nổi                 |
| 20599     | Xã Nam Phước              |
| 20611     | Xã Thu Bồn                |
| 20623     | Xã Duy Xuyên              |
| 20635     | Xã Duy Nghĩa              |
| 20641     | Xã Quế Sơn                |
| 20650     | Xã Xuân Phú               |
| 20656     | Xã Nông Sơn               |
| 20662     | Xã Quế Sơn Trung          |
| 20669     | Xã Quế Phước              |
| 20695     | Xã Thạnh Mỹ               |
| 20698     | Xã La Êê                  |
| 20704     | Xã La Dêê                 |
| 20707     | Xã Nam Giang              |
| 20710     | Xã Bến Giằng              |
| 20716     | Xã Đắc Pring              |
| 20722     | Xã Khâm Đức               |
| 20728     | Xã Phước Hiệp             |
| 20734     | Xã Phước Năng             |
| 20740     | Xã Phước Chánh            |
| 20752     | Xã Phước Thành            |
| 20767     | Xã Việt An                |
| 20770     | Xã Phước Trà              |
| 20779     | Xã Hiệp Đức               |
| 20791     | Xã Thăng Bình             |
| 20794     | Xã Thăng An               |
| 20818     | Xã Đồng Dương             |
| 20827'    | Xã Thăng Phú              |
| 20836     | Xã Thăng Trường           |
| 20848     | Xã Thăng Điền             |
| 20854     | Xã Tiên Phước             |
| 20857     | Xã Sơn Cẩm Hà             |
| 20875     | Xã Lãnh Ngọc              |
| 20878     | Xã Thạnh Bình             |
| 20900     | Xã Trà My                 |
| 20908     | Xã Trà Liên               |
| 20920     | Xã Trà Đốc                |
| 20923     | Xã Trà Tân                |
| 20929     | Xã Trà Giáp               |
| 20938     | Xã Trà Leng               |
| 20941     | Xã Trà Tập                |
| 20944     | Xã Nam Trà My             |
| 20950     | Xã Trà Linh               |
| 20959     | Xã Trà Vân                |
| 20965     | Xã Núi Thành              |
| 20971     | Xã Tam Xuân               |
| 20977     | Xã Đức Phú                |
| 20984     | Xã Tam Anh                |
| 20992     | Xã Tam Hải                |
| 21004     | Xã Tam Mỹ                 |
| 20333     | Đặc khu Hoàng Sa          |

**51. TỈNH QUẢNG NGÃI**

**(Tổng số đơn vị hành chính cấp xã: 96, gồm 86 xã, 09 phường, 01 đặc khu)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 21025     | Phường Cẩm Thành          |
| 21028     | Phường Nghĩa Lộ           |
| 21172     | Phường Trương Quang Trọng |
| 21439     | Phường Đức Phổ            |
| 21451     | Phường Trà Câu            |
| 21478     | Phường Sa Huỳnh           |
| 23284     | Phường Đăk Cấm            |
| 23293     | Phường Kon Tum            |
| 23302     | Phường Đăk Bla            |
| 21034     | Xã An Phú                 |
| 21040     | Xã Bình Sơn               |
| 21061     | Xã Vạn Tường              |
| 21085     | Xã Bình Minh              |
| 21100     | Xã Bình Chương            |
| 21109     | Xã Đông Sơn               |
| 21115     | Xã Trà Bồng               |
| 21124     | Xã Thanh Bồng             |
| 21127     | Xã Đông Trà Bồng          |
| 21136     | Xã Cà Đam                 |
| 21154     | Xã Tây Trà                |
| 21157     | Xã Tây Trà Bồng           |
| 21181     | Xã Thọ Phong              |
| 21196     | Xã Trường Giang           |
| 21205     | Xã Ba Gia                 |
| 21211     | Xã Tịnh Khê               |
| 21220     | Xã Sơn Tịnh               |
| 21235     | Xã Tư Nghĩa               |
| 21238     | Xã Vệ Giang               |
| 21244     | Xã Trà Giang              |
| 21250     | Xã Nghĩa Giang            |
| 21289     | Xã Sơn Hà                 |
| 21292     | Xã Sơn Hạ                 |
| 21307     | Xã Sơn Linh               |
| 21319     | Xã Sơn Thủy               |
| 21325     | Xã Sơn Kỳ                 |
| 21334     | Xã Sơn Tây Thượng         |
| 21340     | Xã Sơn Tây                |
| 21343     | Xã Sơn Tây Hạ             |
| 21349     | Xã Sơn Mai                |
| 21361     | Xã Minh Long              |
| 21364     | Xã Nghĩa Hành             |
| 21370     | Xã Phước Giang            |
| 21385     | Xã Đình Cương             |
| 21388     | Xã Thiện Tín              |
| 21400     | Xã Mộ Đức                 |
| 21409     | Xã Long Phụng             |
| 21421     | Xã Mỏ Cày                 |
| 21433     | Xã Lân Phong              |
| 21457     | Xã Nguyễn Nghiêm          |
| 21472     | Xã Khánh Cường            |
| 21484     | Xã Ba Tơ                  |
| 21490     | Xã Ba Vinh                |
| 21496     | Xã Ba Động                |
| 21499     | Xã Ba Dinh                |
| 21520     | Xã Đặng Thùy Trâm         |
| 21523     | Xã Ba Tô                  |
| 21529     | Xã Ba Vì                  |
| 21538     | Xã Ba Xa                  |
| 23317     | Xã Ngọk Bay               |
| 23326     | Xã la Chim                |
| 23332     | Xã Đăk Rơ Wa              |
| 23341     | Xã Đăk Pék                |
| 23344     | Xã Đăk Plô                |
| 23356     | Xã Xốp                    |
| 23365     | Xã Ngọc Linh              |
| 23368     | Xã Đăk Long               |
| 23374     | Xã Đăk Môn                |
| 23377     | Xã Bờ Y                   |
| 23383     | Xã Dục Nông               |
| 23392     | Xã Sa Loong               |
| 23401     | Xã Đăk Tô                 |
| 23416     | Xã Đăk Sao                |
| 23419     | Xã Đăk Tờ Kan             |
| 23425     | Xã Tu Mơ Rông             |
| 23428     | Xã Ngọk Tụ                |
| 23430     | Xã Kon Đào                |
| 23446     | Xã Măng Ri                |
| 23455     | Xã Măng Bút               |
| 23473     | Xã Măng Đen               |
| 23476     | Xã Kon Plông              |
| 23479     | Xã Đăk Rve                |
| 23485     | Xã Đăk Kôi                |
| 23497     | Xã Kon Braih              |
| 23500     | Xã Đăk Hà                 |
| 23504     | Xã Đăk Pxi                |
| 23510     | Xã Đăk Ui                 |
| 23512     | Xã Đăk Mar                |
| 23515     | Xã Ngọk Réo               |
| 23527     | Xã Sa Thầy                |
| 23530     | Xã Rờ Kơi                 |
| 23534     | Xã Sa Bình                |
| 23535     | Xã la Đal                 |
| 23536     | Xã Mô Rai                 |
| 23538     | Xã la Tơi                 |
| 23548     | Xã Ya Ly                  |
| 21548     | Đặc khu Lý Sơn            |

**52. TỈNH GIA LAI**

**(Tổng số đơn vị hành chính cấp xã: 135, gồm 110 xã, 25 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 21553     | Phường Quy Nhơn Bắc       |
| 21583     | Phường Quy Nhơn           |
| 21589     | Phường Quy Nhơn Tây       |
| 21592     | Phường Quy Nhơn Nam       |
| 21601     | Phường Quy Nhơn Đông      |
| 21637     | Phường Tam Quan           |
| 21640     | Phường Bồng Sơn           |
| 21655     | Phường Hoài Nhơn Bắc      |
| 21661     | Phường Hoài Nhơn Tây      |
| 21664     | Phường Hoài Nhơn          |
| 21670     | Phường Hoài Nhơn Đông     |
| 21673     | Phường Hoài Nhơn Nam      |
| 21907     | Phường Bình Định          |
| 21910     | Phường An Nhơn            |
| 21925     | Phường An Nhơn Bắc        |
| 21934     | Phường An Nhơn Đông       |
| 21943     | Phường An Nhơn Nam        |
| 23563     | Phường Diên Hồng          |
| 23575     | Phường Pleiku             |
| 23584     | Phường Thống Nhất         |
| 23586     | Phường Hội Phú            |
| 23602     | Phường An Phú             |
| 23614     | Phường An Bình            |
| 23617     | Phường An Khê             |
| 24044     | Phường Ayun Pa            |
| 21607     | Xã Nhơn Châu              |
| 21609     | Xã An Lão                 |
| 21616     | Xã An Vinh                |
| 21622     | Xã An Toàn                |
| 21628     | Xã An Hòa                 |
| 21688     | Xã Hoài Ân                |
| 21697     | Xã Ân Hảo                 |
| 21703     | Xã Vạn Đức                |
| 21715     | Xã Ân Tường               |
| 21727     | Xã Kim Sơn                |
| 21730     | Xã Phù Mỹ                 |
| 21733     | Xã Bình Dương             |
| 21739     | Xã Phù Mỹ Bắc             |
| 21751     | Xã Phù Mỹ Đông            |
| 21757     | Xã Phù Mỹ Tây             |
| 21769     | Xã An Lương               |
| 21775     | Xã Phù Mỹ Nam             |
| 21786     | Xã Vĩnh Thạnh             |
| 21787     | Xã Vĩnh Sơn               |
| 21796     | Xã Vĩnh Thịnh             |
| 21805     | Xã Vĩnh Quang             |
| 21808     | Xã Tây Sơn                |
| 21817     | Xã Bình Hiệp              |
| 21820     | Xã Bình Khê               |
| 21829     | Xã Bình An                |
| 21835     | Xã Bình Phú               |
| 21853     | Xã Phù Cát                |
| 21859     | Xã Đề Gi                  |
| 21868     | Xã Hội Sơn                |
| 21871     | Xã Hòa Hội                |
| 21880     | Xã Cát Tiến               |
| 21892     | Xã Xuân An                |
| 21901     | Xã Ngô Mây                |
| 21940     | Xã An Nhơn Tây            |
| 21952     | Xã Tuy Phước              |
| 21964     | Xã Tuy Phước Bắc          |
| 21970     | Xã Tuy Phước Đông         |
| 21985     | Xã Tuy Phước Tây          |
| 21994     | Xã Vân Canh               |
| 21997     | Xã Canh Liên              |
| 22006     | Xã Canh Vinh              |
| 23590     | Xã Biển Hồ                |
| 23611     | Xã Gào                    |
| 23629     | Xã Cửu An                 |
| 23638     | Xã Kbang                  |
| 23644     | Xã Đak Rong               |
| 23647     | Xã Sơn Lang               |
| 23650     | Xã Krong                  |
| 23668     | Xã Tơ Tung                |
| 23674     | Xã Kông Bơ La             |
| 23677     | Xã Đak Đoa                |
| 23683     | Xã Đak Sơmei              |
| 23701     | Xã Kon Gang               |
| 23710     | Xã la Băng                |
| 23714     | Xã KDang                  |
| 23722     | Xã Chư Păh                |
| 23728     | Xã Ia Khươl               |
| 23734     | Xã Ia Ly                  |
| 23938     | Xã Ia Mơ                  |
| 23749     | Xã Ia Phí                 |
| 23764     | Xã Ia Grai                |
| 23767     | Xã Ia Hrung               |
| 23776     | Xã Ia Krái                |
| 23782     | Xã Ia O                   |
| 23788     | Xã Ia Chia                |
| 23794     | Xã Mang Yang              |
| 23798     | Xã Ayun                   |
| 23799     | Xã Hra                    |
| 23812     | Xã Lơ Pang                |
| 23818     | Xã Kon Chiêng             |
| 23824     | Xã Kông Chro              |
| 23830     | Xã Chư Krey               |
| 23833     | Xã Ya Ma                  |
| 23839     | Xã SRó                    |
| 23842     | Xã Đăk Song               |
| 23851     | Xã Chơ Long               |
| 23857     | Xã Đức Cơ                 |
| 23866     | Xã Ia Krêl                |
| 23869     | Xã Ia Dơk                 |
| 23872     | Xã Ia Dom                 |
| 23881     | Xã Ia Pnôn                |
| 23884     | Xã Ia Nan                 |
| 23887     | Xã Chư Prông              |
| 23896     | Xã Bàu Cạn                |
| 23908     | Xã Ia Tôr                 |
| 23911     | Xã Ia Boòng               |
| 23917     | Xã Ia Púch                |
| 23926     | Xã Ia Pia                 |
| 23935     | Xã Ia Lâu                 |
| 23941     | Xã Chư Sê                 |
| 23942     | Xã Chư Pưh                |
| 23947     | Xã Bờ Ngoong              |
| 23954     | Xã AI Bá                  |
| 23971     | Xã Ia Hrú                 |
| 23977     | Xã Ia Ko                  |
| 23986     | Xã Ia Le                  |
| 23995     | Xã Đak Pơ                 |
| 24007     | Xã Ya Hội                 |
| 24013     | Xã Pờ Tó                  |
| 24022     | Xã Ia Pa                  |
| 24028     | Xã Ia Tul                 |
| 24043     | Xã Phú Thiện              |
| 24049     | Xã Chư A Thai             |
| 24061     | Xã Ia Hiao                |
| 24065     | Xã Ia Rbol                |
| 24073     | Xã Ia Sao                 |
| 24076     | Xã Phú Túc                |
| 24100     | Xã Ia Dreh                |
| 24109     | Xã Uar                    |
| 24112     | Xã Ia Rsai                |

**56. TỈNH KHÁNH HÒA**

**(Tổng số đơn vị hành chính cấp xã: 65, gồm 48 xã, 16 phường, 01 đặc khu)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 22333     | Phường Bắc Nha Trang      |
| 22366     | Phường Nha Trang          |
| 22390     | Phường Tây Nha Trang      |
| 22402     | Phường Nam Nha Trang      |
| 22411     | Phường Bắc Cam Ranh       |
| 22420     | Phường Cam Ranh           |
| 22423     | Phường Ba Ngòi            |
| 22432     | Phường Cam Linh           |
| 22528     | Phường Ninh Hòa           |
| 22561     | Phường Đông Ninh Hòa      |
| 22591     | Phường Hòa Thắng          |
| 22738     | Phường Đô Vinh            |
| 22741     | Phường Bảo An             |
| 22759     | Phường Phan Rang          |
| 22780     | Phường Đông Hải           |
| 22834     | Phường Ninh Chử           |
| 22435     | Xã Cam Hiệp               |
| 22453     | Xã Cam Lâm                |
| 22465     | Xã Cam An                 |
| 22480     | Xã Nam Cam Ranh           |
| 22489     | Xã Vạn Ninh               |
| 22498     | Xã Tu Bông                |
| 22504     | Xã Đại Lãnh               |
| 22516     | Xã Vạn Thắng              |
| 22525     | Xã Vạn Hưng               |
| 22546     | Xã Bắc Ninh Hòa           |
| 22552     | Xã Tây Ninh Hòa           |
| 22558     | Xã Hòa Trí                |
| 22576     | Xã Tân Định               |
| 22597     | Xã Nam Ninh Hòa           |
| 22609     | Xã Khánh Vĩnh             |
| 22612     | Xã Trung Khánh Vĩnh       |
| 22615     | Xã Bắc Khánh Vĩnh         |
| 22624     | Xã Tây Khánh Vĩnh         |
| 22648     | Xã Nam Khánh Vĩnh         |
| 22651     | Xã Diên Khánh             |
| 22657     | Xã Diên Điền              |
| 22660     | Xã Diên Lâm               |
| 22672     | Xã Diên Thọ               |
| 22678     | Xã Diên Lạc               |
| 22702     | Xã Suối Hiệp              |
| 22708     | Xã Suối Dầu               |
| 22714     | Xã Khánh Sơn              |
| 22720     | Xã Tây Khánh Sơn          |
| 22732     | Xã Đông Khánh Sơn         |
| 22786     | Xã Bác Ái Tây             |
| 22795     | Xã Bác Ái                 |
| 22801     | Xã Bác Ái Đông            |
| 22810     | Xã Ninh Sơn               |
| 22813     | Xã Lâm Sơn                |
| 22822     | Xã Mỹ Sơn                 |
| 22828     | Xã Anh Dũng               |
| 22840     | Xã Công Hải               |
| 22846     | Xã Vĩnh Hải               |
| 22849     | Xã Thuận Bắc              |
| 22852     | Xã Ninh Hải               |
| 22861     | Xã Xuân Hải               |
| 22870     | Xã Ninh Phước             |
| 22873     | Xã Phước Hậu              |
| 22888     | Xã Phước Dinh             |
| 22891     | Xã Phước Hữu              |
| 22897     | Xã Thuận Nam              |
| 22900     | Xã Phước Hà               |
| 22909     | Xã Cà Ná                  |
| 22736     | Đặc khu Trường Sa         |

**66. TỈNH ĐẮK LẮK**

**(Tổng số đơn vị hành chính cấp xã: 102, gồm 88 xã, 14 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 22015     | Phường Tuy Hòa            |
| 22045     | Phường Bình Kiến          |
| 22051     | Phường Sông Cầu           |
| 22076     | Phường Xuân Đài           |
| 22240     | Phường Phú Yên            |
| 22258     | Phường Đông Hòa           |
| 22261     | Phường Hòa Hiệp           |
| 24121     | Phường Tân Lập            |
| 24133     | Phường Buôn Ma Thuột      |
| 24154     | Phường Thành Nhất         |
| 24163     | Phường Tân An             |
| 24169     | Phường Ea Kao             |
| 24305     | Phường Buôn Hồ            |
| 24340     | Phường Cư Bao             |
| 22057     | Xã Xuân Lộc               |
| 22060     | Xã Xuân Cảnh              |
| 22075     | Xã Xuân Thọ               |
| 22081     | Xã Đồng Xuân              |
| 22090     | Xã Xuân Lãnh              |
| 22096     | Xã Phú Mỡ                 |
| 22111     | Xã Xuân Phước             |
| 22114     | Xã Tuy An Bắc             |
| 22120     | Xã Tuy An Đông            |
| 22132     | Xã Tuy An Tây             |
| 22147     | Xã Ô Loan                 |
| 22153     | Xã Tuy An Nam             |
| 22165     | Xã Sơn Hòa                |
| 22171     | Xã Tây Sơn                |
| 22177     | Xã Vân Hòa                |
| 22192     | Xã Suối Trai              |
| 22207     | Xã Sông Hinh              |
| 22222     | Xã Đức Bình               |
| 22225     | Xã Ea Bá                  |
| 22237     | Xã Ea Ly                  |
| 22250     | Xã Sơn Thành              |
| 22255     | Xã Tây Hòa                |
| 22276     | Xã Hòa Thịnh              |
| 22285     | Xã Hòa Mỹ                 |
| 22291     | Xã Hòa Xuân               |
| 22303     | Xã Phú Hòa 2              |
| 22319     | Xã Phú Hòa 1              |
| 24175     | Xã Hòa Phú                |
| 24181     | Xã Ea Drăng               |
| 24184     | Xã Ea H'Leo               |
| 24187     | Xã Ea Hiao                |
| 24193     | Xã Ea Wy                  |
| 24208     | Xã Ea Khăl                |
| 24211     | Xã Ea Súp                 |
| 24214     | Xã Ia Lốp                 |
| 24217     | Xã Ea Rốk                 |
| 24221     | Xã Ia Rvê                 |
| 24229     | Xã Ea Bung                |
| 24235     | Xã Buôn Đôn               |
| 24241     | Xã Ea Wer                 |
| 24250     | Xã Ea Nuôl                |
| 24259     | Xã Quảng Phú              |
| 24265     | Xã Ea Kiết                |
| 24277     | Xã Ea Tul                 |
| 24280     | Xã Cư M’gar               |
| 24286     | Xã Ea M’Droh              |
| 24301     | Xã Cuôr Đăng              |
| 24310     | Xã Krông Búk              |
| 24313     | Xã Cư Pơng                |
| 24316     | Xã Pơng Drang             |
| 24328     | Xã Ea Drông               |
| 24343     | Xã Krông Năng             |
| 24346     | Xã Dliê Ya                |
| 24352     | Xã Tam Giang              |
| 24364     | Xã Phú Xuân               |
| 24373     | Xã Ea Kar                 |
| 24376     | Xã Ea Knốp                |
| 24400     | Xã Ea Păl                 |
| 24403     | Xã Ea Ô                   |
| 24406     | Xã Cư Yang                |
| 24412     | Xã M’Drắk                 |
| 24415     | Xã Cư Prao                |
| 24433     | Xã Ea Riêng               |
| 24436     | Xã Cư M’ta                |
| 24444     | Xã Krông Á                |
| 24445     | Xã Ea Trang               |
| 24448     | Xã Krông Bông             |
| 24454     | Xã Dang Kang              |
| 24472     | Xã Hòa Sơn                |
| 24478     | Xã Cư Pui                 |
| 24484     | Xã Yang Mao               |
| 24490     | Xã Krông Pắc              |
| 24496     | Xã Ea Kly                 |
| 24502     | Xã Ea Phê                 |
| 24505     | Xã Ea Knuếc               |
| 24526     | Xã Tân Tiến               |
| 24529     | Xã Vụ Bổn                 |
| 24538     | Xã Krông Ana              |
| 24540     | Xã Ea Ning                |
| 24544     | Xã Ea Ktur                |
| 24559     | Xã Ea Na                  |
| 24561     | Xã Dray Bhăng             |
| 24568     | Xã Dur Kmăl               |
| 24580     | Xã Liên Sơn Lắk           |
| 24595     | Xã Đắk Liêng              |
| 24598     | Xã Đắk Phơi               |
| 24604     | Xã Krông Nô               |
| 24607     | Xã Nam Ka                 |

**68. TỈNH LÂM ĐỒNG**

**(Tổng số đơn vị hành chính cấp xã: 124, gồm 103 xã, 20 phường, 01 đặc khu)**

|           |                             |
|-----------|-----------------------------|
| **Mã số** | **Tên đơn vị hành chính**   |
| 22918     | Phường Mũi Né               |
| 22924     | Phường Phú Thủy             |
| 22933     | Phường Hàm Thắng            |
| 22945     | Phường Phan Thiết           |
| 22954     | Phường Tiến Thành           |
| 22960     | Phường Bình Thuận           |
| 23231     | Phường Phước Hội            |
| 23235     | Phường La Gi                |
| 24611     | Phường Bắc Gia Nghĩa        |
| 24615     | Phường Nam Gia Nghĩa        |
| 24617     | Phường Đông Gia Nghĩa       |
| 24778     | Phường Lâm Viên - Đà Lạt    |
| 24781     | Phường Xuân Hương - Đà Lạt  |
| 24787     | Phường Cam Ly - Đà Lạt      |
| 24805     | Phường Xuân Trường - Đà Lạt |
| 24820     | Phường 2 Bảo Lộc            |
| 24823     | Phường 1 Bảo Lộc            |
| 24829     | Phường B'Lao                |
| 24841     | Phường 3 Bảo Lộc            |
| 24846     | Phường Lang Biang - Đà Lạt  |
| 22963     | Xã Tuyên Quang              |
| 22969     | Xã Liên Hương               |
| 22972     | Xã Phan Rí Cửa              |
| 22978     | Xã Tuy Phong                |
| 22981     | Xã Vĩnh Hảo                 |
| 23005     | Xã Bắc Bình                 |
| 23008     | Xã Phan Sơn                 |
| 23020     | Xã Hải Ninh                 |
| 23023     | Xã Sông Lũy                 |
| 23032     | Xã Lương Sơn                |
| 23041     | Xã Hồng Thái                |
| 23053     | Xã Hòa Thắng                |
| 23059     | Xã Hàm Thuận                |
| 23065     | Xã La Dạ                    |
| 23074     | Xã Đông Giang               |
| 23086     | Xã Hồng Sơn                 |
| 23089     | Xã Hàm Thuận Bắc            |
| 23095     | Xã Hàm Liêm                 |
| 23110     | Xã Hàm Thuận Nam            |
| 23122     | Xã Hàm Thạnh                |
| 23128     | Xã Hàm Kiệm                 |
| 23134     | Xã Tân Lập                  |
| 23143     | Xã Tân Thành                |
| 23149     | Xã Tánh Linh                |
| 23152     | Xã Bắc Ruộng                |
| 23158     | Xã Nghị Đức                 |
| 23173     | Xã Đồng Kho                 |
| 23188     | Xã Suối Kiết                |
| 23191     | Xã Đức Linh                 |
| 23194     | Xã Hoài Đức                 |
| 23200     | Xã Nam Thành                |
| 23227     | Xã Trà Tân                  |
| 23230     | Xã Tân Minh                 |
| 23236     | Xã Hàm Tân                  |
| 23246     | Xã Tân Hải                  |
| 23266     | Xã Sơn Mỹ                   |
| 24616     | Xã Quảng Sơn                |
| 24620     | Xã Quảng Hòa                |
| 24631     | Xã Quảng Khê                |
| 24637     | Xã Tà Đùng                  |
| 24640     | Xã Cư Jút                   |
| 24646     | Xã Đắk Wil                  |
| 24649     | Xã Nam Dong                 |
| 24664     | Xã Đức Lập                  |
| 24670     | Xã Đắk Mil                  |
| 24678     | Xã Đắk Sắk                  |
| 24682     | Xã Thuận An                 |
| 24688     | Xã Krông Nô                 |
| 24697     | Xã Nam Đà                   |
| 24703     | Xã Nâm Nung                 |
| 24712     | Xã Quảng Phú                |
| 24717     | Xã Đức An                   |
| 24718     | Xã Đắk Song                 |
| 24722     | Xã Thuận Hạnh               |
| 24730     | Xã Trường Xuân              |
| 24733     | Xã Kiến Đức                 |
| 24736     | Xã Quảng Trực               |
| 24739     | Xã Tuy Đức                  |
| 24748     | Xã Quảng Tân                |
| 24751     | Xã Nhân Cơ                  |
| 24760     | Xã Quảng Tín                |
| 24848     | Xã Lạc Dương                |
| 24853     | Xã Đam Rông 4               |
| 24868     | Xã Nam Ban Lâm Hà           |
| 24871     | Xã Đinh Văn Lâm Hà          |
| 24875     | Xã Đam Rông 3               |
| 24877     | Xã Đam Rông 2               |
| 24883     | Xã Nam Hà Lâm Hà            |
| 24886     | Xã Đam Rông 1               |
| 24895     | Xã Phú Sơn Lâm Hà           |
| 24907     | Xã Phúc Thọ Lâm Hà          |
| 24916     | Xã Tân Hà Lâm Hà            |
| 24931     | Xã Đơn Dương                |
| 24934     | Xã D'Ran                    |
| 24943     | Xã Ka Đô                    |
| 24955     | Xã Quảng Lập                |
| 24958     | Xã Đức Trọng                |
| 24967     | Xã Hiệp Thạnh               |
| 24976     | Xã Tân Hội                  |
| 24985     | Xã Ninh Gia                 |
| 24988     | Xã Tà Năng                  |
| 24991     | Xã Tà Hine                  |
| 25000     | Xã Di Linh                  |
| 25007     | Xã Đinh Trang Thượng        |
| 25015     | Xã Gia Hiệp                 |
| 25018     | Xã Bảo Thuận                |
| 25036     | Xã Hòa Ninh                 |
| 25042     | Xã Hòa Bắc                  |
| 25051     | Xã Sơn Điền                 |
| 25054     | Xã Bảo Lâm 1                |
| 25057     | Xã Bảo Lâm 5                |
| 25063     | Xã Bảo Lâm 4                |
| 25084     | Xã Bảo Lâm 2                |
| 25093     | Xã Bảo Lâm 3                |
| 25099     | Xã Đạ Huoai                 |
| 25105     | Xã Đạ Huoai 2               |
| 25114     | Xã Đạ Huoai 3               |
| 25126     | Xã Đạ Tẻh                   |
| 25135     | Xã Đạ Tẻh 3                 |
| 25138     | Xã Đạ Tẻh 2                 |
| 25159     | Xã Cát Tiên                 |
| 25162     | Xã Cát Tiên 3               |
| 25180     | Xã Cát Tiên 2               |
| 23272     | Đặc khu Phú Quý             |

**75. TỈNH ĐỒNG NAI**

**(Tổng số đơn vị hành chính cấp xã: 95, gồm 72 xã, 23 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 25195     | Phường Bình Phước         |
| 25210     | Phường Đồng Xoài          |
| 25217     | Phường Phước Long         |
| 25220     | Phường Phước Bình         |
| 25326     | Phường Bình Long          |
| 25333     | Phường An Lộc             |
| 25432     | Phường Chơn Thành         |
| 25441     | Phường Minh Hưng          |
| 25993     | Phường Trảng Dài          |
| 26005     | Phường Hố Nai             |
| 26017     | Phường Tam Hiệp           |
| 26020     | Phường Long Bình          |
| 26041     | Phường Trấn Biên          |
| 26068     | Phường Biên Hòa           |
| 26080     | Phường Long Khánh         |
| 26089     | Phường Bình Lộc           |
| 26098     | Phường Bảo Vinh           |
| 26104     | Phường Xuân Lập           |
| 26113     | Phường Hàng Gòn           |
| 26188     | Phường Tân Triều          |
| 26374     | Phường Tam Phước          |
| 26377     | Phường Phước Tân          |
| 26380     | Phường Long Hưng          |
| 25222     | Xã Bù Gia Mập             |
| 25225     | Xã Đăk Ơ                  |
| 25231     | Xã Đa Kia 1               |
| 25246     | Xã Bình Tân               |
| 25252     | Xã Phú Riềng              |
| 25255     | Xã Long Hà                |
| 25261     | Xã Phú Trung              |
| 25267     | Xã Phú Nghĩa              |
| 25270     | Xã Lộc Ninh               |
| 25279     | Xã Lộc Tấn                |
| 25280     | Xã Lộc Thạnh              |
| 25292     | Xã Lộc Quang              |
| 25294     | Xã Lộc Thành              |
| 25303     | Xã Lộc Hưng               |
| 25308     | Xã Thiện Hưng             |
| 25309     | Xã Hưng Phước             |
| 25318     | Xã Tân Tiến               |
| 25345     | Xã Tân Hưng               |
| 25349     | Xã Minh Đức               |
| 25351     | Xã Tân Quan               |
| 25357     | Xã Tân Khai               |
| 25363     | Xã Đồng Phú               |
| 25378     | Xã Tân Lợi                |
| 25387     | Xã Thuận Lợi              |
| 25390     | Xã Đồng Tâm               |
| 25396     | Xã Bù Đăng                |
| 25399     | Xã Đak Nhau               |
| 25402     | Xã Thọ Sơn                |
| 25405     | Xã Bom Bo                 |
| 25417     | Xã Nghĩa Trung            |
| 25420     | Xã Phước Sơn              |
| 25450     | Xã Nha Bích               |
| 26116     | Xã Tân Phú                |
| 26119     | Xã Đak Lua                |
| 26122     | Xã Nam Cát Tiên           |
| 26134     | Xã Tà Lài                 |
| 26158     | Xã Phú Lâm                |
| 26170     | Xã Trị An                 |
| 26173     | Xã Phú Lý                 |
| 26179     | Xã Tân An                 |
| 26206     | Xã Định Quán              |
| 26209     | Xã Thanh Sơn              |
| 26215     | Xã Phú Vinh               |
| 26221     | Xã Phú Hòa                |
| 26227     | Xã La Ngà                 |
| 26248     | Xã Trảng Bom              |
| 26254     | Xã Bàu Hàm                |
| 26278     | Xã Bình Minh              |
| 26281     | Xã Hưng Thịnh             |
| 26296     | Xã An Viễn                |
| 26299     | Xã Thống Nhất             |
| 26311     | Xã Gia Kiệm               |
| 26326     | Xã Dầu Giây               |
| 26332     | Xã Xuân Quế               |
| 26341     | Xã Cẩm Mỹ                 |
| 26347     | Xã Xuân Đường             |
| 26359     | Xã Xuân Đông              |
| 26362     | Xã Sông Ray               |
| 26368     | Xã Long Thành             |
| 26383     | Xã An Phước               |
| 26389     | Xã Bình An                |
| 26413     | Xã Long Phước             |
| 26422     | Xã Phước Thái             |
| 26425     | Xã Xuân Lộc               |
| 26428     | Xã Xuân Bắc               |
| 26434     | Xã Xuân Thành             |
| 26446     | Xã Xuân Hòa               |
| 26458     | Xã Xuân Phú               |
| 26461     | Xã Xuân Định              |
| 26485     | Xã Nhơn Trạch             |
| 26491     | Xã Đại Phước              |
| 26503     | Xã Phước An               |

**79. THÀNH PHỐ HỒ CHÍ MINH**

**(Tổng số đơn vị hành chính cấp xã: 168, gồm 54 xã, 113 phường, 01 đặc khu)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 25747     | Phường Thủ Dầu Một        |
| 25750     | Phường Phú Lợi            |
| 25760     | Phường Bình Dương         |
| 25768     | Phường Phú An             |
| 25771     | Phường Chánh Hiệp         |
| 25813     | Phường Bến Cát            |
| 25837     | Phường Chánh Phú Hòa      |
| 25840     | Phường Long Nguyên        |
| 25843     | Phường Tây Nam            |
| 25846     | Phường Thới Hòa           |
| 25849     | Phường Hòa Lợi            |
| 25888     | Phường Tân Uyên           |
| 25891     | Phường Tân Khánh          |
| 25912     | Phường Vĩnh Tân           |
| 25915     | Phường Bình Cơ            |
| 25920     | Phường Tân Hiệp           |
| 25942     | Phường Dĩ An              |
| 25945     | Phường Tân Đông Hiệp      |
| 25951     | Phường Đông Hòa           |
| 25966     | Phường Lái Thiêu          |
| 25969     | Phường Thuận Giao         |
| 25975     | Phường An Phú             |
| 25978     | Phường Thuận An           |
| 25987     | Phường Bình Hòa           |
| 26506     | Phường Vũng Tàu           |
| 26526     | Phường Tam Thắng          |
| 26536     | Phường Rạch Dừa           |
| 26542     | Phường Phước Thắng        |
| 26560     | Phường Bà Rịa             |
| 26566     | Phường Long Hương         |
| 26572     | Phường Tam Long           |
| 26704     | Phường Phú Mỹ             |
| 26710     | Phường Tân Hải            |
| 26713     | Phường Tân Phước          |
| 26725     | Phường Tân Thành          |
| 26737     | Phường Tân Định           |
| 26740     | Phường Sài Gòn            |
| 26743     | Phường Bến Thành          |
| 26758     | Phường Cầu Ông Lãnh       |
| 26767     | Phường An Phú Đông        |
| 26773     | Phường Thới An            |
| 26782     | Phường Tân Thới Hiệp      |
| 26785     | Phường Trung Mỹ Tây       |
| 26791     | Phường Đông Hưng Thuận    |
| 26800     | Phường Linh Xuân          |
| 26803     | Phường Tam Bình           |
| 26809     | Phường Hiệp Bình          |
| 26824     | Phường Thủ Đức            |
| 26833     | Phường Long Bình          |
| 26842     | Phường Tăng Nhơn Phú      |
| 26848     | Phường Phước Long         |
| 26857     | Phường Long Phước         |
| 26860     | Phường Long Trường        |
| 26876     | Phường An Nhơn            |
| 26878     | Phường An Hội Đông        |
| 26882     | Phường An Hội Tây         |
| 26884     | Phường Gò Vấp             |
| 26890     | Phường Hạnh Thông         |
| 26898     | Phường Thông Tây Hội      |
| 26905     | Phường Bình Lợi Trung     |
| 26911     | Phường Bình Quới          |
| 26929     | Phường Bình Thạnh         |
| 26944     | Phường Gia Định           |
| 26956     | Phường Thạnh Mỹ Tây       |
| 26968     | Phường Tân Sơn Nhất       |
| 26977     | Phường Tân Sơn Hòa        |
| 26983     | Phường Bảy Hiền           |
| 26995     | Phường Tân Hòa            |
| 27004     | Phường Tân Bình           |
| 27007     | Phường Tân Sơn            |
| 27013     | Phường Tây Thạnh          |
| 27019     | Phường Tân Sơn Nhì        |
| 27022     | Phường Phú Thọ Hòa        |
| 27028     | Phường Phú Thạnh          |
| 27031     | Phường Tân Phú            |
| 27043     | Phường Đức Nhuận          |
| 27058     | Phường Cầu Kiệu           |
| 27073     | Phường Phú Nhuận          |
| 27094     | Phường An Khánh           |
| 27097     | Phường Bình Trưng         |
| 27112     | Phường Cát Lái            |
| 27139     | Phường Xuân Hòa           |
| 27142     | Phường Nhiêu Lộc          |
| 27154     | Phường Bàn Cờ             |
| 27163     | Phường Hòa Hưng           |
| 27169     | Phường Diên Hồng          |
| 27190     | Phường Vườn Lài           |
| 27211     | Phường Hòa Bình           |
| 27226     | Phường Phú Thọ            |
| 27232     | Phường Bình Thới          |
| 27238     | Phường Minh Phụng         |
| 27259     | Phường Xóm Chiếu          |
| 27265     | Phường Khánh Hội          |
| 27286     | Phường Vĩnh Hội           |
| 27301     | Phường Chợ Quán           |
| 27316     | Phường An Đông            |
| 27343     | Phường Chợ Lớn            |
| 27349     | Phường Phú Lâm            |
| 27364     | Phường Bình Phú           |
| 27367     | Phường Bình Tây           |
| 27373     | Phường Bình Tiên          |
| 27418     | Phường Chánh Hưng         |
| 27424     | Phường Bình Đông          |
| 27427     | Phường Phú Định           |
| 27439     | Phường Bình Hưng Hòa      |
| 27442     | Phường Bình Tân           |
| 27448     | Phường Bình Trị Đông      |
| 27457     | Phường Tân Tạo            |
| 27460     | Phường An Lạc             |
| 27475     | Phường Tân Hưng           |
| 27478     | Phường Tân Thuận          |
| 27484     | Phường Phú Thuận          |
| 27487     | Phường Tân Mỹ             |
| 25777     | Xã Dầu Tiếng              |
| 25780     | Xã Minh Thạnh             |
| 25792     | Xã Long Hòa               |
| 25807     | Xã Thanh An               |
| 25819     | Xã Trừ Văn Thố            |
| 25822     | Xã Bàu Bàng               |
| 25858     | Xã Phú Giáo               |
| 25864     | Xã Phước Thành            |
| 25867     | Xã An Long                |
| 25882     | Xã Phước Hòa              |
| 25906     | Xã Bắc Tân Uyên           |
| 25909     | Xã Thường Tân             |
| 26545     | Xã Long Sơn               |
| 26575     | Xã Ngãi Giao              |
| 26584     | Xã Xuân Sơn               |
| 26590     | Xã Bình Giã               |
| 26596     | Xã Châu Đức               |
| 26608     | Xã Kim Long               |
| 26617     | Xã Nghĩa Thành            |
| 26620     | Xã Hồ Tràm                |
| 26632     | Xã Xuyên Mộc              |
| 26638     | Xã Bàu Lâm                |
| 26641     | Xã Hòa Hội                |
| 26647     | Xã Hòa Hiệp               |
| 26656     | Xã Bình Châu              |
| 26659     | Xã Long Điền              |
| 26662     | Xã Long Hải               |
| 26680     | Xã Đất Đỏ                 |
| 26686     | Xã Phước Hải              |
| 26728     | Xã Châu Pha               |
| 27496     | Xã Tân An Hội             |
| 27508     | Xã An Nhơn Tây            |
| 27511     | Xã Nhuận Đức              |
| 27526     | Xã Thái Mỹ                |
| 27541     | Xã Phú Hòa Đông           |
| 27544     | Xã Bình Mỹ                |
| 27553     | Xã Củ Chi                 |
| 27559     | Xã Hóc Môn                |
| 27568     | Xã Đông Thạnh             |
| 27577     | Xã Xuân Thới Sơn          |
| 27592     | Xã Bà Điểm                |
| 27595     | Xã Tân Nhựt               |
| 27601     | Xã Vĩnh Lộc               |
| 27604     | Xã Tân Vĩnh Lộc           |
| 27610     | Xã Bình Lợi               |
| 27619     | Xã Bình Hưng              |
| 27628     | Xã Hưng Long              |
| 27637     | Xã Bình Chánh             |
| 27655     | Xã Nhà Bè                 |
| 27658     | Xã Hiệp Phước             |
| 27664     | Xã Cần Giờ                |
| 27667     | Xã Bình Khánh             |
| 27673     | Xã An Thới Đông           |
| 27676     | Xã Thạnh An               |
| 26732     | Đặc khu Côn Đảo           |

**80. TỈNH TÂY NINH**

**(Tổng số đơn vị hành chính cấp xã: 96, gồm 82 xã, 14 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 25459     | Phường Tân Ninh           |
| 25480     | Phường Bình Minh          |
| 25567     | Phường Ninh Thạnh         |
| 25630     | Phường Long Hoa           |
| 25633     | Phường Thanh Điền         |
| 25645     | Phường Hòa Thành          |
| 25654     | Phường Gò Dầu             |
| 25672     | Phường Gia Lộc            |
| 25708     | Phường Trảng Bàng         |
| 25732     | Phường An Tịnh            |
| 27694     | Phường Long An            |
| 27712     | Phường Tân An             |
| 27715     | Phường Khánh Hậu          |
| 27787     | Phường Kiến Tường         |
| 25486     | Xã Tân Biên               |
| 25489     | Xã Tân Lập                |
| 25498     | Xã Thạnh Bình             |
| 25510     | Xã Trà Vong               |
| 25516     | Xã Tân Châu               |
| 25522     | Xã Tân Đông               |
| 25525     | Xã Tân Hội                |
| 25531     | Xã Tân Hòa                |
| 25534     | Xã Tân Thành              |
| 25549     | Xã Tân Phú                |
| 25552     | Xã Dương Minh Châu        |
| 25573     | Xã Cầu Khởi               |
| 25579     | Xã Lộc Ninh               |
| 25585     | Xã Châu Thành             |
| 25588     | Xã Hảo Đước               |
| 25591     | Xã Phước Vinh             |
| 25606     | Xã Hòa Hội                |
| 25621     | Xã Ninh Điền              |
| 25657     | Xã Thạnh Đức              |
| 25663     | Xã Phước Thạnh            |
| 25666     | Xã Truông Mít             |
| 25681     | Xã Bến Cầu                |
| 25684     | Xã Long Chữ               |
| 25702     | Xã Long Thuận             |
| 25711     | Xã Hưng Thuận             |
| 25729     | Xã Phước Chỉ              |
| 27721     | Xã Tân Hưng               |
| 27727     | Xã Hưng Điền              |
| 27736     | Xã Vĩnh Thạnh             |
| 27748     | Xã Vĩnh Châu              |
| 27757     | Xã Vĩnh Hưng              |
| 27763     | Xã Khánh Hưng             |
| 27775     | Xã Tuyên Bình             |
| 27793     | Xã Bình Hiệp              |
| 27811     | Xã Bình Hòa               |
| 27817     | Xã Tuyên Thạnh            |
| 27823     | Xã Mộc Hóa                |
| 27826     | Xã Tân Thạnh              |
| 27838     | Xã Nhơn Hòa Lập           |
| 27841     | Xã Hậu Thạnh              |
| 27856     | Xã Nhơn Ninh              |
| 27865     | Xã Thạnh Hóa              |
| 27868     | Xã Bình Thành             |
| 27877     | Xã Thạnh Phước            |
| 27889     | Xã Tân Tây                |
| 27898     | Xã Đông Thành             |
| 27907     | Xã Mỹ Quý                 |
| 27925     | Xã Đức Huệ                |
| 27931     | Xã Hậu Nghĩa              |
| 27937     | Xã Đức Hòa                |
| 27943     | Xã An Ninh                |
| 27952     | Xã Hiệp Hòa               |
| 27964     | Xã Đức Lập                |
| 27976     | Xã Mỹ Hạnh                |
| 27979     | Xã Hòa Khánh              |
| 27991     | Xã Bến Lức                |
| 27994     | Xã Thạnh Lợi              |
| 28003     | Xã Lương Hòa              |
| 28015     | Xã Bình Đức               |
| 28018     | Xã Mỹ Yên                 |
| 28036     | Xã Thủ Thừa               |
| 28051     | Xã Mỹ Thạnh               |
| 28066     | Xã Mỹ An                  |
| 28072     | Xã Tân Long               |
| 28075     | Xã Tân Trụ                |
| 28087     | Xã Nhựt Tảo               |
| 28093     | Xã Vàm Cỏ                 |
| 28108     | Xã Cần Đước               |
| 28114     | Xã Rạch Kiến              |
| 28126     | Xã Long Cang              |
| 28132     | Xã Mỹ Lệ                  |
| 28138     | Xã Tân Lân                |
| 28144     | Xã Long Hưu               |
| 28159     | Xã Cần Giuộc              |
| 28165     | Xã Phước Lý               |
| 28177     | Xã Mỹ Lộc                 |
| 28201     | Xã Phước Vĩnh Tây         |
| 28207     | Xã Tân Tập                |
| 28210     | Xã Tầm Vu                 |
| 28222     | Xã Vĩnh Công              |
| 28225     | Xã Thuận Mỹ               |
| 28243     | Xã An Lục Long            |

**82. TỈNH ĐỒNG THÁP**

**(Tổng số đơn vị hành chính cấp xã: 102, gồm 82 xã, 20 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 28249     | Phường Đạo Thạnh          |
| 28261     | Phường Mỹ Tho             |
| 28270     | Phường Thới Sơn           |
| 28273     | Phường Mỹ Phong           |
| 28285     | Phường Trung An           |
| 28297     | Phường Long Thuận         |
| 28306     | Phường Gò Công            |
| 28315     | Phường Bình Xuân          |
| 28435     | Phường Mỹ Phước Tây       |
| 28436     | Phường Thanh Hòa          |
| 28439     | Phường Cai Lậy            |
| 28477     | Phường Nhị Quý            |
| 28729     | Phường Sơn Qui            |
| 29869     | Phường Cao Lãnh           |
| 29884     | Phường Mỹ Ngãi            |
| 29888     | Phường Mỹ Trà             |
| 29905     | Phường Sa Đéc             |
| 29954     | Phường An Bình            |
| 29955     | Phường Hồng Ngự           |
| 29978     | Phường Thường Lạc         |
| 28321     | Xã Tân Phước 1            |
| 28327     | Xã Tân Phước 2            |
| 28336     | Xã Hưng Thạnh             |
| 28345     | Xã Tân Phước 3            |
| 28360     | Xã Cái Bè                 |
| 28366     | Xã Hậu Mỹ                 |
| 28378     | Xã Mỹ Thiện               |
| 28393     | Xã Hội Cư                 |
| 28405     | Xã Mỹ Đức Tây             |
| 28414     | Xã Mỹ Lợi                 |
| 28426     | Xã Thanh Hưng             |
| 28429     | Xã An Hữu                 |
| 28444     | Xã Thạnh Phú              |
| 28456     | Xã Mỹ Thành               |
| 28468     | Xã Tân Phú                |
| 28471     | Xã Bình Phú               |
| 28501     | Xã Hiệp Đức               |
| 28504     | Xã Long Tiên              |
| 28516     | Xã Ngũ Hiệp               |
| 28519     | Xã Châu Thành             |
| 28525     | Xã Tân Hương              |
| 28537     | Xã Long Hưng              |
| 28543     | Xã Long Định              |
| 28564     | Xã Bình Trưng             |
| 28576     | Xã Vĩnh Kim               |
| 28582     | Xã Kim Sơn                |
| 28594     | Xã Chợ Gạo                |
| 28603     | Xã Mỹ Tịnh An             |
| 28615     | Xã Lương Hòa Lạc          |
| 28627     | Xã Tân Thuận Bình         |
| 28633     | Xã An Thạnh Thủy          |
| 28648     | Xã Bình Ninh              |
| 28651     | Xã Vĩnh Bình              |
| 28660     | Xã Đồng Sơn               |
| 28663     | Xã Phú Thành              |
| 28678     | Xã Vĩnh Hựu               |
| 28687     | Xã Long Bình              |
| 28693     | Xã Tân Thới               |
| 28696     | Xã Tân Phú Đông           |
| 28702     | Xã Tân Hòa                |
| 28720     | Xã Gia Thuận              |
| 28723     | Xã Tân Đông               |
| 28738     | Xã Tân Điền               |
| 28747     | Xã Gò Công Đông           |
| 29926     | Xã Tân Hồng               |
| 29929     | Xã Tân Hộ Cơ              |
| 29938     | Xã Tân Thành              |
| 29944     | Xã An Phước               |
| 29971     | Xã Thường Phước           |
| 29983     | Xã Long Khánh             |
| 29992     | Xã Long Phú Thuận         |
| 30001     | Xã Tràm Chim              |
| 30010     | Xã Tam Nông               |
| 30019     | Xã An Hòa                 |
| 30025     | Xã Phú Cường              |
| 30028     | Xã An Long                |
| 30034     | Xã Phú Thọ                |
| 30037     | Xã Tháp Mười              |
| 30043     | Xã Phương Thịnh           |
| 30046     | Xã Trường Xuân            |
| 30055     | Xã Mỹ Quí                 |
| 30061     | Xã Đốc Binh Kiều          |
| 30073     | Xã Thanh Mỹ               |
| 30076     | Xã Mỹ Thọ                 |
| 30085     | Xã Ba Sao                 |
| 30088     | Xã Phong Mỹ               |
| 30112     | Xã Mỹ Hiệp                |
| 30118     | Xã Bình Hàng Trung        |
| 30130     | Xã Thanh Bình             |
| 30154     | Xã Tân Long               |
| 30157     | Xã Tân Thạnh              |
| 30163     | Xã Bình Thành             |
| 30169     | Xã Lấp Vò                 |
| 30178     | Xã Mỹ An Hưng             |
| 30184     | Xã Tân Khánh Trung        |
| 30208     | Xã Hòa Long               |
| 30214     | Xã Tân Dương              |
| 30226     | Xã Lai Vung               |
| 30235     | Xã Phong Hòa              |
| 30244     | Xã Phú Hựu                |
| 30253     | Xã Tân Nhuận Đông         |
| 30259     | Xã Tân Phú Trung          |

**86. TỈNH VĨNH LONG**

**(Tổng số đơn vị hành chính cấp xã: 124, gồm 105 xã, 19 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 28756     | Phường Phú Khương         |
| 28777     | Phường An Hội             |
| 28783     | Phường Sơn Đông           |
| 28789     | Phường Bến Tre            |
| 28858     | Phường Phú Tân            |
| 29242     | Phường Trà Vinh           |
| 29254     | Phường Nguyệt Hóa         |
| 29263     | Phường Long Đức           |
| 29398     | Phường Hòa Thuận          |
| 29512     | Phường Duyên Hải          |
| 29516     | Phường Trường Long Hòa    |
| 29551     | Phường Long Châu          |
| 29557     | Phường Phước Hậu          |
| 29566     | Phường Tân Ngãi           |
| 29590     | Phường Thanh Đức          |
| 29593     | Phường Tân Hạnh           |
| 29770     | Phường Cái Vồn            |
| 29771     | Phường Bình Minh          |
| 29812     | Phường Đông Thành         |
| 28807     | Xã Giao Long              |
| 28810     | Xã Phú Túc                |
| 28840     | Xã Tân Phú                |
| 28861     | Xã Tiên Thủy              |
| 28870     | Xã Chợ Lách               |
| 28879     | Xã Phú Phụng              |
| 28894     | Xã Vĩnh Thành             |
| 28901     | Xã Hưng Khánh Trung       |
| 28903     | Xã Mỏ Cày                 |
| 28915     | Xã Phước Mỹ Trung         |
| 28921     | Xã Tân Thành Bình         |
| 28945     | Xã Đồng Khởi              |
| 28948     | Xã Nhuận Phú Tân          |
| 28957     | Xã An Định                |
| 28969     | Xã Thành Thới             |
| 28981     | Xã Hương Mỹ               |
| 28984     | Xã Giồng Trôm             |
| 28987     | Xã Lương Hòa              |
| 28993     | Xã Lương Phú              |
| 28996     | Xã Châu Hòa               |
| 29020     | Xã Phước Long             |
| 29029     | Xã Tân Hào                |
| 29044     | Xã Hưng Nhượng            |
| 29050     | Xã Bình Đại               |
| 29062     | Xã Phú Thuận              |
| 29077     | Xã Lộc Thuận              |
| 29083     | Xã Châu Hưng              |
| 29089     | Xã Thạnh Trị              |
| 29104     | Xã Thạnh Phước            |
| 29107     | Xã Thới Thuận             |
| 29110     | Xã Ba Tri                 |
| 29122     | Xã Mỹ Chánh Hòa           |
| 29125     | Xã Bảo Thạnh              |
| 29137     | Xã Tân Xuân               |
| 29143     | Xã An Ngãi Trung          |
| 29158     | Xã An Hiệp                |
| 29167     | Xã Tân Thủy               |
| 29182     | Xã Thạnh Phú              |
| 29191     | Xã Quới Điền              |
| 29194     | Xã Đại Điền               |
| 29221     | Xã Thạnh Hải              |
| 29224     | Xã An Qui                 |
| 29227     | Xã Thạnh Phong            |
| 29266     | Xã Càng Long              |
| 29275     | Xã An Trường              |
| 29278     | Xã Tân An                 |
| 29287     | Xã Bình Phú               |
| 29302     | Xã Nhị Long               |
| 29308     | Xã Cầu Kè                 |
| 29317     | Xã An Phú Tân             |
| 29329     | Xã Phong Thạnh            |
| 29335     | Xã Tam Ngãi               |
| 29341     | Xã Tiểu Cần               |
| 29362     | Xã Hùng Hòa               |
| 29365     | Xã Tập Ngãi               |
| 29371     | Xã Tân Hòa                |
| 29374     | Xã Châu Thành             |
| 29386     | Xã Song Lộc               |
| 29407     | Xã Hưng Mỹ                |
| 29410     | Xã Hòa Minh               |
| 29413     | Xã Long Hòa               |
| 29416     | Xã Cầu Ngang              |
| 29419     | Xã Mỹ Long                |
| 29431     | Xã Vinh Kim               |
| 29446     | Xã Nhị Trường             |
| 29455     | Xã Hiệp Mỹ                |
| 29461     | Xã Trà Cú                 |
| 29467     | Xã Tập Sơn                |
| 29476     | Xã Lưu Nghiệp Anh         |
| 29489     | Xã Hàm Giang              |
| 29491     | Xã Đại An                 |
| 29497     | Xã Đôn Châu               |
| 29506     | Xã Long Hiệp              |
| 29513     | Xã Long Thành             |
| 29518     | Xã Long Hữu               |
| 29530     | Xã Ngũ Lạc                |
| 29533     | Xã Long Vĩnh              |
| 29536     | Xã Đông Hải               |
| 29584     | Xã An Bình                |
| 29602     | Xã Long Hồ                |
| 29611     | Xã Phú Quới               |
| 29623     | Xã Nhơn Phú               |
| 29638     | Xã Bình Phước             |
| 29641     | Xã Cái Nhum               |
| 29653     | Xã Tân Long Hội           |
| 29659     | Xã Trung Thành            |
| 29668     | Xã Quới An                |
| 29677     | Xã Quới Thiện             |
| 29683     | Xã Trung Hiệp             |
| 29698     | Xã Trung Ngãi             |
| 29701     | Xã Hiếu Phụng             |
| 29713     | Xã Hiếu Thành             |
| 29719     | Xã Tam Bình               |
| 29728     | Xã Cái Ngang              |
| 29734     | Xã Hòa Hiệp               |
| 29740     | Xã Song Phú               |
| 29767     | Xã Ngãi Tứ                |
| 29785     | Xã Tân Lược               |
| 29788     | Xã Mỹ Thuận               |
| 29800     | Xã Tân Quới               |
| 29821     | Xã Trà Ôn                 |
| 29830     | Xã Hòa Bình               |
| 29836     | Xã Trà Côn                |
| 29845     | Xã Vĩnh Xuân              |
| 29857     | Xã Lục Sĩ Thành           |

**91. TỈNH AN GIANG**

**(Tổng số đơn vị hành chính cấp xã: 102, gồm 85 xã, 14 phường, 03 đặc khu)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 30292     | Phường Bình Đức           |
| 30301     | Phường Mỹ Thới            |
| 30307     | Phường Long Xuyên         |
| 30316     | Phường Châu Đốc           |
| 30325     | Phường Vĩnh Tế            |
| 30376     | Phường Tân Châu           |
| 30377     | Phường Long Phú           |
| 30502     | Phường Thới Sơn           |
| 30505     | Phường Chi Lăng           |
| 30520     | Phường Tịnh Biên          |
| 30742     | Phường Rạch Giá           |
| 30760     | Phường Vĩnh Thông         |
| 30766     | Phường Tô Châu            |
| 30769     | Phường Hà Tiên            |
| 30313     | Xã Mỹ Hòa Hưng            |
| 30337     | Xã An Phú                 |
| 30341     | Xã Khánh Bình             |
| 30346     | Xã Nhơn Hội               |
| 30352     | Xã Phú Hữu                |
| 30367     | Xã Vĩnh Hậu               |
| 30385     | Xã Vĩnh Xương             |
| 30388     | Xã Tân An                 |
| 30403     | Xã Châu Phong             |
| 30406     | Xã Phú Tân                |
| 30409     | Xã Chợ Vàm                |
| 30421     | Xã Phú Lâm                |
| 30430     | Xã Hòa Lạc                |
| 30436     | Xã Phú An                 |
| 30445     | Xã Bình Thạnh Đông        |
| 30463     | Xã Châu Phú               |
| 30469     | Xã Mỹ Đức                 |
| 30478     | Xã Vĩnh Thạnh Trung       |
| 30481     | Xã Thạnh Mỹ Tây           |
| 30487     | Xã Bình Mỹ                |
| 30526     | Xã An Cư                  |
| 30538     | Xã Núi Cấm                |
| 30544     | Xã Tri Tôn                |
| 30547     | Xã Ba Chúc                |
| 30568     | Xã Vĩnh Gia               |
| 30577     | Xã Ô Lâm                  |
| 30580     | Xã Cô Tô                  |
| 30589     | Xã An Châu                |
| 30595     | Xã Cần Đăng               |
| 30604     | Xã Vĩnh An                |
| 30607     | Xã Bình Hòa               |
| 30619     | Xã Vĩnh Hanh              |
| 30628     | Xã Chợ Mới                |
| 30631     | Xã Long Điền              |
| 30643     | Xã Cù Lao Giêng           |
| 30658     | Xã Nhơn Mỹ                |
| 30664     | Xã Long Kiến              |
| 30673     | Xã Hội An                 |
| 30682     | Xã Thoại Sơn              |
| 30685     | Xã Phú Hòa                |
| 30688     | Xã Óc Eo                  |
| 30691     | Xã Tây Phú                |
| 30697     | Xã Vĩnh Trạch             |
| 30709     | Xã Định Mỹ                |
| 30781     | Xã Tiên Hải               |
| 30787     | Xã Kiên Lương             |
| 30790     | Xã Hòa Điền               |
| 30793     | Xã Vĩnh Điều              |
| 30796     | Xã Giang Thành            |
| 30811     | Xã Sơn Hải                |
| 30814     | Xã Hòn Nghệ               |
| 30817     | Xã Hòn Đất                |
| 30823     | Xã Bình Sơn               |
| 30826     | Xã Bình Giang             |
| 30835     | Xã Sơn Kiên               |
| 30838     | Xã Mỹ Thuận               |
| 30850     | Xã Tân Hiệp               |
| 30856     | Xã Tân Hội                |
| 30874     | Xã Thạnh Đông             |
| 30880     | Xã Châu Thành             |
| 30886     | Xã Thạnh Lộc              |
| 30898     | Xã Bình An                |
| 30904     | Xã Giồng Riềng            |
| 30910     | Xã Thạnh Hưng             |
| 30928     | Xã Ngọc Chúc              |
| 30934     | Xã Hòa Hưng               |
| 30943     | Xã Long Thạnh             |
| 30949     | Xã Hòa Thuận              |
| 30952     | Xã Gò Quao                |
| 30958     | Xã Định Hòa               |
| 30970     | Xã Vĩnh Hòa Hưng          |
| 30982     | Xã Vĩnh Tuy               |
| 30985     | Xã An Biên                |
| 30988     | Xã Tây Yên                |
| 31006     | Xã Đông Thái              |
| 31012     | Xã Vĩnh Hòa               |
| 31018     | Xã An Minh                |
| 31024     | Xã Đông Hòa               |
| 31027     | Xã u Minh Thượng          |
| 31031     | Xã Tân Thạnh              |
| 31036     | Xã Đông Hưng              |
| 31042     | Xã Vân Khánh              |
| 31051     | Xã Vĩnh Phong             |
| 31064     | Xã Vĩnh Bình              |
| 31069     | Xã Vĩnh Thuận             |
| 31078     | Đặc khu Phú Quốc          |
| 31105     | Đặc khu Thổ Châu          |
| 31108     | Đặc khu Kiên Hải          |

**92. THÀNH PHỐ CẦN THƠ**

**(Tổng số đơn vị hành chính cấp xã: 103, gồm 72 xã, 31 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 31120     | Phường Cái Khế            |
| 31135     | Phường Ninh Kiều          |
| 31147     | Phường Tân An             |
| 31150     | Phường An Bình            |
| 31153     | Phường Ô Môn              |
| 31157     | Phường Thới Long          |
| 31162     | Phường Phước Thới         |
| 31168     | Phường Bình Thủy          |
| 31174     | Phường Thới An Đông       |
| 31183     | Phường Long Tuyền         |
| 31186     | Phường Cái Răng           |
| 31201     | Phường Hưng Phú           |
| 31207     | Phường Thốt Nốt           |
| 31213     | Phường Tân Lộc            |
| 31217     | Phường Trung Nhứt         |
| 31228     | Phường Thuận Hưng         |
| 31321     | Phường Vị Thanh           |
| 31333     | Phường Vị Tân             |
| 31340     | Phường Ngã Bảy            |
| 31411     | Phường Đại Thành          |
| 31471     | Phường Long Mỹ            |
| 31473     | Phường Long Bình          |
| 31480     | Phường Long Phú 1         |
| 31507     | Phường Sóc Trăng          |
| 31510     | Phường Phú Lợi            |
| 31684     | Phường Mỹ Xuyên           |
| 31732     | Phường Ngã Năm            |
| 31753     | Phường Mỹ Quới            |
| 31783     | Phường Vĩnh Châu          |
| 31789     | Phường Khánh Hòa          |
| 31804     | Phường Vĩnh Phước         |
| 31231     | Xã Thạnh An               |
| 31232     | Xã Vĩnh Thạnh             |
| 31237     | Xã Vĩnh Trinh             |
| 31246     | Xã Thạnh Quới             |
| 31249     | Xã Thạnh Phú              |
| 31255     | Xã Trung Hưng             |
| 31258     | Xã Thới Lai               |
| 31261     | Xã Cờ Đỏ                  |
| 31264     | Xã Thới Hưng              |
| 31273     | Xã Đông Hiệp              |
| 31282     | Xã Đông Thuận             |
| 31288     | Xã Trường Thành           |
| 31294     | Xã Trường Xuân            |
| 31299     | Xã Phong Điền             |
| 31309     | Xã Trường Long            |
| 31315     | Xã Nhơn Ái                |
| 31338     | Xã Hỏa Lựu                |
| 31342     | Xã Tân Hòa                |
| 31348     | Xã Trường Long Tây        |
| 31360     | Xã Thạnh Xuân             |
| 31366     | Xã Châu Thành             |
| 31369     | Xã Đông Phước             |
| 31378     | Xã Phú Hữu                |
| 31393     | Xã Hòa An                 |
| 31396     | Xã Hiệp Hưng              |
| 31399     | Xã Tân Bình               |
| 31408     | Xã Thạnh Hòa              |
| 31420     | Xã Phụng Hiệp             |
| 31426     | Xã Phương Bình            |
| 31432     | Xã Tân Phước Hưng         |
| 31441     | Xã Vị Thủy                |
| 31453     | Xã Vĩnh Thuận Đông        |
| 31459     | Xã Vĩnh Tường             |
| 31465     | Xã Vị Thanh 1             |
| 31489     | Xã Vĩnh Viễn              |
| 31492     | Xã Lương Tâm              |
| 31495     | Xã Xà Phiên               |
| 31528     | Xã Kế Sách                |
| 31531     | Xã An Lạc Thôn            |
| 31537     | Xã Phong Nẫm              |
| 31540     | Xã Thới An Hội            |
| 31552     | Xã Nhơn Mỹ                |
| 31561     | Xã Đại Hải                |
| 31567     | Xã Mỹ Tú                  |
| 31569     | Xã Phú Tâm                |
| 31570     | Xã Hồ Đắc Kiện            |
| 31579     | Xã Long Hưng              |
| 31582     | Xã Thuận Hòa              |
| 31591     | Xã Mỹ Hương               |
| 31594     | Xã An Ninh                |
| 31603     | Xã Mỹ Phước               |
| 31615     | Xã An Thạnh               |
| 31633     | Xã Cù Lao Dung            |
| 31639     | Xã Long Phú               |
| 31645     | Xã Đại Ngãi               |
| 31654     | Xã Trường Khánh           |
| 31666     | Xã Tân Thạnh              |
| 31673     | Xã Trần Đề                |
| 31675     | Xã Liêu Tú                |
| 31679     | Xã Lịch Hội Thượng        |
| 31687     | Xã Tài Văn                |
| 31699     | Xã Thạnh Thới An          |
| 31708     | Xã Nhu Gia                |
| 31717     | Xã Hòa Tú                 |
| 31723     | Xã Ngọc Tố                |
| 31726     | Xã Gia Hòa                |
| 31741     | Xã Tân Long               |
| 31756     | Xã Phú Lộc                |
| 31759     | Xã Lâm Tân                |
| 31777     | Xã Vĩnh Lợi               |
| 31795     | Xã Vĩnh Hải               |
| 31810     | Xã Lai Hòa                |

**96. TỈNH CÀ MAU**

**(Tổng số đơn vị hành chính cấp xã: 64, gồm 55 xã, 09 phường)**

|           |                           |
|-----------|---------------------------|
| **Mã số** | **Tên đơn vị hành chính** |
| 31825     | Phường Bạc Liêu           |
| 31834     | Phường Vĩnh Trạch         |
| 31840     | Phường Hiệp Thành         |
| 31942     | Phường Giá Rai            |
| 31951     | Phường Láng Tròn          |
| 32002     | Phường An Xuyên           |
| 32014     | Phường Lý Văn Lâm         |
| 32025     | Phường Tân Thành          |
| 32041     | Phường Hòa Thành          |
| 31843     | Xã Hồng Dân               |
| 31849     | Xã Ninh Quới              |
| 31858     | Xã Vĩnh Lộc               |
| 31864     | Xã Ninh Thạnh Lợi         |
| 31867     | Xã Phước Long             |
| 31876     | Xã Vĩnh Phước             |
| 31882     | Xã Vĩnh Thanh             |
| 31885     | Xã Phong Hiệp             |
| 31891     | Xã Hòa Bình               |
| 31894     | Xã Châu Thới              |
| 31900     | Xã Vĩnh Lợi               |
| 31906     | Xã Hưng Hội               |
| 31918     | Xã Vĩnh Mỹ                |
| 31927     | Xã Vĩnh Hậu               |
| 31957     | Xã Phong Thạnh            |
| 31972     | Xã Gành Hào               |
| 31975     | Xã Đông Hải               |
| 31985     | Xã Long Điền              |
| 31988     | Xã An Trạch               |
| 31993     | Xã Định Thành             |
| 32044     | Xã Nguyễn Phích           |
| 32047     | Xã U Minh                 |
| 32059     | Xã Khánh An               |
| 32062     | Xã Khánh Lâm              |
| 32065     | Xã Thới Bình              |
| 32069     | Xã Biển Bạch              |
| 32071     | Xã Trí Phải               |
| 32083     | Xã Tân Lộc                |
| 32092     | Xã Hồ Thị Kỷ              |
| 32095     | Xã Trần Văn Thời          |
| 32098     | Xã Sông Đốc               |
| 32104     | Xã Đá Bạc                 |
| 32110     | Xã Khánh Bình             |
| 32119     | Xã Khánh Hưng             |
| 32128     | Xã Cái Nước               |
| 32134     | Xã Lương Thế Trân         |
| 32137     | Xã Tân Hưng               |
| 32140     | Xã Hưng Mỹ                |
| 32152     | Xã Đầm Dơi                |
| 32155     | Xã Tạ An Khương           |
| 32161     | Xã Trần Phán              |
| 32167     | Xã Tân Thuận              |
| 32182     | Xã Quách Phẩm             |
| 32185     | Xã Thanh Tùng             |
| 32188     | Xã Tân Tiến               |
| 32191     | Xã Năm Căn                |
| 32201     | Xã Đất Mới                |
| 32206     | Xã Tam Giang              |
| 32212     | Xã Cái Đôi Vàm            |
| 32214     | Xã Phú Mỹ                 |
| 32218     | Xã Phú Tân                |
| 32227     | Xã Nguyễn Việt Khái       |
| 32236     | Xã Tân Ân                 |
| 32244     | Xã Phan Ngọc Hiển         |
| 32248     | Xã Đất Mũi                |

 

 
